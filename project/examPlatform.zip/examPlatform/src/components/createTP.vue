<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->

<script lang="ts">
import { defineComponent } from "vue";
// import {type UploadUserFile, type UploadProps, ElMessage, ElMessageBox} from "element-plus";
import pageHeader from "@/components/pageHeader.vue";
import { sleep, $, request } from "../../../../jsPackage/src/comFunc";
import { appUrl, stdRsp } from "@/assets/common";
import { onMounted, ref, nextTick } from "vue";
import uploader from 'vue-simple-uploader';
import { Store_ } from "@/stores"


export default defineComponent({
    data() {
        return {
            formData: {
                name: "",
                desc: "",
                duration: "",
                file: null as File
            }
        }
    },
    components: {
        pageHeader,
        uploader: uploader.Uploader,
        uploaderBtn: uploader.UploaderBtn,
        uploaderDrop: uploader.UploaderDrop,
        uploaderUnsupport: uploader.UploaderUnsupport,
        uploaderList: uploader.UploaderList,
    },
    setup() {
        const store = Store_();

        const uploaderRef = ref(null)
        const flag = ref(false)

        const options = {
            target: appUrl,
            testChunks: false
        }
        const attrs = {
            accept: 'image/*'
        }
        const statusText = {
            success: 'success',
            error: 'error',
            uploading: 'uploading',
            paused: 'paused',
            waiting: 'waiting'
        }
        const complete = () => {
            if (uploaderRef.value.files.length > 0)
                flag.value = true
        }
        const onFileAdded = (file: any) => {
            if (uploaderRef.value.files.length > 1)
                uploaderRef.value.removeFile(file)

            // for (let elem of $.class('need-move')) elem.classList.add('move-bottom')

        }
        onMounted(() => {
            nextTick(() => {
                window.uploader = uploaderRef.value.uploader
            })
        })
        const removeFile = () => {
            flag.value = false
            uploaderRef.value.files = []
            uploaderRef.value.fileList = []
            // for (let elem of $.class('need-move')) elem.classList.remove('move-bottom')
        }
        return {
            uploaderRef,
            options,
            attrs,
            statusText,
            complete,
            onFileAdded,
            removeFile,
            flag,
            store
        }
    },
    methods: {
        submit() {
            this.formData.file = this.uploaderRef.files[0] || null

            const fd = new FormData();

            for (let [key, value] of Object.entries(this.formData)) fd.append(key, value as string | Blob);

            fd.append("userId", this.store.user.id);

            request(appUrl, "/createTP", fd, "POST", "multipart/form-data")
                .then((res: stdRsp<any>) => {
                    if (res.code !== 200) console.error(`${res.code} - Failed to create test paper: ${res.msg}`)
                })

        },
        valueValid(event: any) {
            const [hour, minute] = event.target.value.split(":")

            if (Number(hour) * 60 + Number(minute) > 180) {
                const res = confirm("Are you sure your exam will take three hours?");

                if (!res) event.target.value = "00:00";
            }

        },
    },
    watch: {
    }
})
</script>

<template>
    <pageHeader>

        <div class="main-body">

            <h1>Create a new test paper</h1>

            <p class="stdText-22" style="margin: 20px 0;">The following form will help you create a new test paper.</p>

            <div class="form-container">

                <form @submit.prevent="submit">

                    <div class="field-group">

                        <input class="input-text-field field-widget" type="text" id="test-name" name="name"
                               placeholder="Enter the name of the test" v-model="formData.name" required>
                        <label class="field" for="test-name">Test Name</label>

                    </div>

                    <div class="field-group optional">

                        <input class="input-text-field field-widget" type="text" id="test-description" name="desc"
                               v-model="formData.desc" placeholder="Enter a brief description of the test">
                        <label class="field" for="test-description">Test Description</label>

                    </div>

                    <div class="field-group optional">

                        <input class="input-time-field field-widget" type="time" id="test-duration" name="duration"
                               v-model="formData.duration" @change="valueValid">
                        <label class="field" for="test-duration">Test Duration</label>

                    </div>

                    <div class="field-group optional">

                        <uploader
                                :options="options"
                                :file-status-text="statusText"
                                class="field-widget uploader-main"
                                ref="uploaderRef"
                                @file-added="onFileAdded"
                                @complete="complete"
                        >

                            <!-- <uploader-btn>select files</uploader-btn>-->
                            <uploader-btn :attrs="attrs" class="disguise-button">select images</uploader-btn>
                            <!-- <uploader-btn :directory="true">select folder</uploader-btn>-->

                            <uploader-list class="uploader-list" v-if="flag"></uploader-list>

                            <div class="icon-wrapper close-icon console-btn" v-if="flag" @click="removeFile">

                                <svg viewBox="0 0 20 20" width="24" height="24">
                                    <title>Close</title>
                                    <rect x="2" y="2" width="16" height="16" stroke="white" rx="2" ry="2" fill="#ccc" opacity="0"/>
                                    <line x1="4" y1="4" x2="16" y2="16" stroke="white" stroke-width="2"/>
                                    <line x1="16" y1="4" x2="4" y2="16" stroke="white" stroke-width="2"/>
                                </svg>

                            </div>

                        </uploader>

                        <input class="input-file-field field-widget" type="file" id="test-file" name="fileName"
                               accept="image/*">

                        <label class="field" for="test-file">Upload a test image</label>

                    </div>

                    <div class="field-group need-move">

                        <input class="input-submit-field field-widget" type="submit" value="Create Test Paper">

                    </div>

                </form>

            </div>

        </div>

    </pageHeader>

</template>

<style>
.uploader-main .uploader-btn {
    margin-right: 4px;
}

.uploader-main uploader-list {
    max-height: 440px;
    overflow: auto;
    overflow-x: hidden;
    overflow-y: auto;
}

.uploader-list, .uploader-file-progress {
    background: #404040 !important;
}

.main-body {
    padding: 0 15%;
    color: honeydew;
}

.form-container {
    background-color: #656565;
    padding: 50px 30px 20px 30px;
    border-radius: 10px;
}

.optional::before {
    content: "*";
    color: white;
}

.field-group {
    align-items: center;
    align-content: center;
    display: flex;
    margin-bottom: 40px;
}

.field {
    font-size: 1.2em;
}

.input-text-field {
    display: inline-block;
    padding: 8px 10px;
    font-size: 16px;
    border: 1px solid #cccbcb;
    width: 40%;
}

.input-file-field {
    display: none;
}

.input-time-field {
    display: inline-block;
    padding: 6px 10px;
    font-size: 16px;
    border: 1px solid #cccbcb;
}

.input-submit-field {
    margin-top: 20px;
    background-color: #52a3ff;
    color: white;
    font-size: 12px;
    font-weight: bold;
    padding: 16px 40px;
    line-height: 1.4;
    text-align: center;
    border-radius: 24px;
    vertical-align: baseline;
    cursor: pointer;
    text-decoration: none;
    position: relative;
    overflow: visible;
    border: none;
    transition: background-color 0.3s ease-in-out;
}

.input-submit-field:hover {
    background-color: #217fff;
}

.move-bottom {
    margin-top: 100px;
}

.field-widget {
    position: absolute;
    margin-left: 20%;
}

.uploader-main {
    width: 41.5%;
    margin-top: 2%;
    display: flex;
    flex-direction: column;
}

.disguise-button {
    font-size: 12px;
    font-weight: bold;
    color: #4b97ff;
    text-decoration: none;
    padding: 11px 32px;
    max-width: 20%;;
    border: 1px solid #cccbcb;
    border-radius: 19px;
    text-align: center;
    vertical-align: baseline;
    margin-bottom: 10px;
    float: left;
}

.uploader-file-info {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
}

.uploader-list-wrapper {
    display: flex;
    flex-direction: row;
}

.console-btn {
    position: absolute;
    float: right;
    display: flex;
    flex-direction: row;
    right: 0;
    bottom: 10%;
}

.icon-wrapper {
    border-radius: 5px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.close-icon:hover {
    background-color: red;
}


</style>
