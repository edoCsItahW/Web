/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */

import { defineStore } from 'pinia'
import { request } from '../../../../jsPackage/src/comFunc'
import { appUrl, type stdRsp, type UserInfoRsp } from "@/assets/common";
import { defaultLogo } from "@/assets/common";


interface obj {
    [key: string]: any
}


export const Store_ = defineStore('main', {
    state: () => {
        return {
            user: null as UserInfoRsp,
            window_: {title: "Exam Platform", leftIcon: false, bgColor: "#3289ff", logo: defaultLogo}
        }
    },
    getters: {

    },
    actions: {
        updateUser(): void {
            request(appUrl, "user", { userId: Number.parseInt(localStorage.getItem("userId") as string) }, "POST")
                .then((res: stdRsp<UserInfoRsp>) => {
                    if (res.code === 200) {
                        this.user = res.data;
                        localStorage.setItem("user", JSON.stringify(res.data));
                    }
                    else
                        console.error(`${res.code} - Failed to get user info: ${res.msg}`)
                })
        },
        updateWindow(key: string, value: any) {
            (this.window_ as obj)[key] = value;
        },
        updateUserId(uid: number) {
            localStorage.setItem("userId", uid.toString());
        }
    }
})
