/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
import { type UserInfoReq, type stdReq, type NormalReq, type RegAndLogReq, type CreateTPReq } from "@/assets/common";


let user = [
    {
        id: 0,
        name: "admin",
        password: "eastasdf64asdfa32fw3aw3fa3wasf224f",
        ip: "127.0.0.1",
        TPs: []
    }
]


function stdRsq(data: any, code: number = 200, msg: string = "ok") {
    return {code: code, msg: msg, data: data};
}


function userInfo(userId: number) {
    const result = user.find(item => {
        return item.id === userId
    })

    if (result)
        return stdRsq(result)
    else
        return stdRsq(null, 404, "User not found!")
}


function nomarl(data: NormalReq<any>) {
    switch (data.type) {
        case "captcha":
            return stdRsq(Array.from({length: 4}, () => Math.floor(Math.random() * 10)).join(''));

        default:
            return stdRsq(null, 400, "Invalid request type!")
    }
}


function register(data: RegAndLogReq) {
    if (user.some(item => item.name === data.name))
        return stdRsq(null, 400, '用户名已存在!');

    if (user.some(item => item.ip === data.ip))
        return stdRsq(null, 400, 'IP地址已存在!');

    user.push({id: user.length + 1, name: data.name, password: data.password, ip: data.ip, TPs: []})

    return stdRsq(null);
}


function login(data: RegAndLogReq) {
    if (user.some(item => item.name === data.name && item.password === data.password))
        return stdRsq(user.findIndex(item => item.name === data.name && item.password === data.password) + 1)

    else
        return stdRsq(null, 400, '用户名或密码错误!')

}


function createTP(data: CreateTPReq) {
    console.log(data)
}


export default [
    {
        url: "/api",
        method: "POST",
        response: (data: stdReq<NormalReq<any>>) => nomarl(data.body)
    },
    {
        url: "/api/user",
        method: "POST",
        response: (data: stdReq<UserInfoReq>) => userInfo(data.body.userId)
    },
    {
        url: "/api/register",
        method: "POST",
        response: (data: stdReq<RegAndLogReq>) => register(data.body)
    },
    {
        url: "/api/login",
        method: "POST",
        response: (data: stdReq<RegAndLogReq>) => login(data.body)
    },
    {
        url: "/api/createTP",
        method: "POST",
        response: (data: stdReq<CreateTPReq>) => createTP(data.body, data.query)
    }
]
