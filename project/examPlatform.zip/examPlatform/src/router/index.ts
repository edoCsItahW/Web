/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */

import {createRouter, createWebHistory} from 'vue-router'
import { Store_ } from "@/stores";
import { defaultLogo, loginLogo, createTPLogo } from "@/assets/common";
import home from "../App.vue";
import login from "../components/login.vue";
import createTP from "@/components/createTP.vue";


const router = createRouter({
    mode: 'history',
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: 'home',
            component: (home as any)
        },
        {
            path: '/login',
            name: 'login',
            component: login
        },
        {
            path: '/createTP',
            name: 'createTP',
            component: createTP
        }
    ]
})


router.beforeEach((to, from, next) => {
    const store = Store_()

    switch (to.name) {
        case 'home':
            store.window_.title = 'Exam Platform';
            store.window_.leftIcon = true;
            store.window_.bgColor = "#3289ff";
            store.window_.logo = defaultLogo;
            break;
        case 'login':
            store.window_.title = 'Login';
            store.window_.leftIcon = false;
            store.window_.bgColor = "#3289ff";
            store.window_.logo = loginLogo;
            break;
        case 'createTP':
            store.window_.title = 'Create Test Paper';
            store.window_.leftIcon = false;
            store.window_.bgColor = "#202020";
            store.window_.logo = createTPLogo;
            break;
    }

    next();
})


export default router
