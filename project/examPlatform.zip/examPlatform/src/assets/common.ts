/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
export const appUrl = location.origin + "/api/"

export interface TPRsp {
    id: number,
    name: string,
    desc: string,
    fileName: string,
    fileData: string,
    quesPool: object
}

export interface UserInfoRsp {
    name: string,
    password: string,
    id: number,
    ip: string,
    TPs: Array<TPRsp>
}


export interface stdRsp<T> {
    code: number,
    msg: string,
    data: T
}


export interface stdReq<T> {
    url: string,
    body: T,
    query: object,
    headers: object,
}


export interface RegAndLogReq {
    name: string,
    password: string,
    ip: string
}


export interface NormalReq<T> {
    type: string,
    data: T
}


export interface UserInfoReq {
    userId: number
}


export interface CreateTPReq {
    userId: string
    name: string,
    desc: string,
    duration: string,
    file: File
}


export const defaultLogo = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 256 286\">\n" +
    "                <defs>\n" +
    "                    <linearGradient x1=\"0%\" y1=\"50%\" x2=\"100%\" y2=\"50%\" id=\"IconifyId19082901379fdac601560\">\n" +
    "                        <stop stop-color=\"#52F2C9\" offset=\"0%\"/>\n" +
    "                        <stop stop-color=\"#52F2C9\" offset=\"9.876%\"/>\n" +
    "                        <stop stop-color=\"#8573E2\" offset=\"100%\"/>\n" +
    "                    </linearGradient>\n" +
    "                </defs>\n" +
    "                <path d=\"M22.37 285.192c-3.854 0-7.706-1.016-11.214-3.048C4.171 278.096 0 270.859 0 262.786V21.908c0-7.887 4.073-14.96 10.895-18.92c6.822-3.96 14.983-3.985 21.832-.071l155.474 88.847a7.995 7.995 0 0 1-7.933 13.88L24.795 16.799c-2.658-1.518-4.994-.493-5.876.019c-.881.512-2.931 2.032-2.931 5.09v240.879c0 3.32 2.226 4.969 3.183 5.523c.957.555 3.494 1.668 6.375.015l200.493-114.952h-23.111a7.995 7.995 0 0 1-7.994-7.995v-5.33h-9.992v18.154a7.995 7.995 0 0 1-7.994 7.994h-25.314a7.995 7.995 0 0 1-7.994-7.994v-33.308h-10.242v56.373a7.994 7.994 0 0 1-7.994 7.994h-26.23a7.995 7.995 0 0 1-7.994-7.994V101.41h-9.825v108.583a7.995 7.995 0 0 1-7.995 7.994H46.714a7.994 7.994 0 0 1-7.994-7.994V65.77h-3.331a7.994 7.994 0 1 1 0-15.988h11.325a7.994 7.994 0 0 1 7.994 7.994V202h10.658V93.417a7.994 7.994 0 0 1 7.994-7.994h25.814a7.994 7.994 0 0 1 7.994 7.994v79.855h10.242v-56.373a7.995 7.995 0 0 1 7.994-7.994h26.23a7.994 7.994 0 0 1 7.994 7.994v33.308h9.326v-18.153a7.994 7.994 0 0 1 7.994-7.994h25.98a7.994 7.994 0 0 1 7.994 7.994v5.329h34.144c5.02 0 9.261 3.26 10.552 8.11c1.292 4.852-.767 9.789-5.123 12.285L33.498 282.194c-3.487 1.999-7.308 2.998-11.128 2.998\"\n" +
    "                      fill=\"url(#IconifyId19082901379fdac601560)\"/>\n" +
    "            </svg>"


export const loginLogo = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 256 256\">\n" +
    "                    <path fill=\"#F7DF1E\" d=\"M0 0h256v256H0z\"/>\n" +
    "                    <path d=\"m67.312 213.932l19.59-11.856c3.78 6.701 7.218 12.371 15.465 12.371c7.905 0 12.89-3.092 12.89-15.12v-81.798h24.057v82.138c0 24.917-14.606 36.259-35.916 36.259c-19.245 0-30.416-9.967-36.087-21.996m85.07-2.576l19.588-11.341c5.157 8.421 11.859 14.607 23.715 14.607c9.969 0 16.325-4.984 16.325-11.858c0-8.248-6.53-11.17-17.528-15.98l-6.013-2.58c-17.357-7.387-28.87-16.667-28.87-36.257c0-18.044 13.747-31.792 35.228-31.792c15.294 0 26.292 5.328 34.196 19.247l-18.732 12.03c-4.125-7.389-8.591-10.31-15.465-10.31c-7.046 0-11.514 4.468-11.514 10.31c0 7.217 4.468 10.14 14.778 14.608l6.014 2.577c20.45 8.765 31.963 17.7 31.963 37.804c0 21.654-17.012 33.51-39.867 33.51c-22.339 0-36.774-10.654-43.819-24.574\"/>\n" +
    "                </svg>"


export const createTPLogo = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 256 256\">\n" +
    "                    <defs>\n" +
    "                        <linearGradient id=\"IconifyId1908614ef135babcd1560\" x1=\"43.896%\" x2=\"66.16%\" y1=\"1.951%\"\n" +
    "                                        y2=\"95.244%\">\n" +
    "                            <stop offset=\"28%\" stop-color=\"#07C3F2\"/>\n" +
    "                            <stop offset=\"94%\" stop-color=\"#087CFA\"/>\n" +
    "                        </linearGradient>\n" +
    "                        <linearGradient id=\"IconifyId1908614ef135babcd1561\" x1=\"33.063%\" x2=\"70.362%\" y1=\"15.078%\"\n" +
    "                                        y2=\"84.685%\">\n" +
    "                            <stop offset=\"14%\" stop-color=\"#FCF84A\"/>\n" +
    "                            <stop offset=\"37%\" stop-color=\"#07C3F2\"/>\n" +
    "                        </linearGradient>\n" +
    "                        <linearGradient id=\"IconifyId1908614ef135babcd1562\" x1=\"44.416%\" x2=\"56.203%\" y1=\"25.058%\"\n" +
    "                                        y2=\"90.203%\">\n" +
    "                            <stop offset=\"28%\" stop-color=\"#07C3F2\"/>\n" +
    "                            <stop offset=\"94%\" stop-color=\"#087CFA\"/>\n" +
    "                        </linearGradient>\n" +
    "                    </defs>\n" +
    "                    <path fill=\"url(#IconifyId1908614ef135babcd1560)\"\n" +
    "                          d=\"M34.507 231.36L0 26.827L63.813.347L104.56 24.56l37.333-20.133l77.787 29.866L176.053 256z\"/>\n" +
    "                    <path fill=\"url(#IconifyId1908614ef135babcd1561)\"\n" +
    "                          d=\"m256 86.693l-33.04-81.6L163.013 0L70.48 88.907l24.907 114.586l46.506 32.614L256 168.4l-28-52.507z\"/>\n" +
    "                    <path fill=\"url(#IconifyId1908614ef135babcd1562)\"\n" +
    "                          d=\"m204.72 74.533l23.28 41.36l28-29.2l-20.56-50.826z\"/>\n" +
    "                    <path d=\"M48 48h160v160H48z\"/>\n" +
    "                    <path fill=\"#FFF\"\n" +
    "                          d=\"M67.947 177.76h60v10h-60zm56.8-109.84l-8.934 35.013L105.6 67.92H95.44L85.2 102.933L76.293 67.92h-14l17.147 60.027h11.253l9.814-34.747l9.706 34.747H121.6l17.12-60.027zm16.48 51.707l7.813-9.6a27.57 27.57 0 0 0 17.973 7.306c5.334 0 8.694-2.133 8.694-5.68v-.16c0-1.899-.665-3.27-3.058-4.57l-.382-.2l-.41-.198l-.216-.1l-.454-.198l-.238-.1l-.5-.198l-.531-.2l-.278-.1l-.58-.2l-.303-.102l-.63-.204l-.667-.206l-.347-.104l-.72-.21l-.758-.214l-.795-.216l-.835-.221l-1.605-.416l-1.144-.307l-.748-.207l-.734-.21l-.72-.215l-.707-.217l-.694-.222l-.68-.227l-.334-.115l-.658-.235l-.643-.241l-.629-.248l-.614-.255l-.301-.13l-.591-.267l-.576-.275c-5.582-2.748-8.889-6.796-8.998-14.338l-.002-.574c0-10.792 8.59-17.98 20.68-18.13l.386-.003a34.67 34.67 0 0 1 22.347 7.653l-6.88 9.974a28.1 28.1 0 0 0-15.653-5.92c-5.067 0-7.734 2.32-7.734 5.333v.187c0 2.402.988 3.856 4.09 5.227l.456.196q.237.098.487.194l.518.195l.548.196l.58.196l.611.199l.646.2l.679.203l1.083.312l.767.213l.803.217l1.719.452q.426.112.843.225l.826.23q.205.057.407.116l.8.236l.781.242l.765.247l.746.252l.728.26l.357.131l.7.27c7.724 3.045 12.013 7.432 12.138 15.507l.002.524c0 11.946-9.12 18.667-22.106 18.667a38.24 38.24 0 0 1-25.52-9.627\"/>\n" +
    "                </svg>"
