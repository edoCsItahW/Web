<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->

<script>
import createTP from "@/components/createTP.vue";
import scanQues from "@/components/scanQues.vue";
import exam from "@/components/exam.vue";
import login from "@/components/login.vue";
import { request, sleep } from "../../../jsPackage/src/comFunc/index.js"

const apiUrl = location.href + "api/";


export default {
    data() {
        return {
            userInfo: null,
            showFlag: "item",
            popupFlag: {type: "createTP", flag: false, overflow: "hidden", back: false},
            infoForScanQues: null,
            examTPid: null,
            dataReady: false,
        }
    },
    created() {
        this.getFileData();
        // this.getUsers();
    },
    template: {

    },
    computed: {
        loginFlag() {
            return this.dataReady && this.popupFlag.type === "login";
        },
        createTPFlag() {
            return this.dataReady && this.popupFlag.type === "createTP";
        },
        scanQuesFlag() {
            return this.dataReady && this.popupFlag.type === "scanQues";
        },
        examFlag() {
            return this.dataReady && this.popupFlag.type === "exam";
        }
    },
    methods: {
        async handleMsg(msg) {
            if (typeof msg !== "object") {
                console.error("子组件传递的消息格式错误!")
                return;
            }

            if (msg.type === "closePopup") {
                this.popupFlag.back = false;
                this.popupFlag.flag = msg.data;
            }
            else if (msg.type === "cancelScroll") {
                this.popupFlag.overflow = msg.data;
                const popup = document.getElementById("popup")
                popup.scroll(0, 0)
            }
            else if (msg.type === "showScroll") this.popupFlag.overflow = msg.data;
            else if (msg.type === "beginExam") {
                this.popupFlag.type = "exam";
                this.examTPid = msg.data;
            }
            else if (msg.type === "resetBack") this.popupFlag.back = msg.data;
            else if (msg.type === "backScanQues") {
                this.popupFlag.back = false;
                this.popupFlag.type = msg.data;
            }
            else if (msg.type === "updateTP") {
                const len = this.userInfo.TPs.length;

                let count = 0;

                while (this.userInfo.TPs.length === len && count < 10) {
                    await sleep(1000)

                    this.getFileData(this.userInfo.id);
                    count++;
                }
            }
            else if (msg.type === "login") {
                this.getFileData(msg.data);
            }
            else console.error(`未知的消息类型 ${msg.type}!`)

        },
        getFileData(args=1) {
            request(apiUrl, "", {type: "userInfo", data: args}, "POST")
                .then(res => {
                    this.userInfo = res.data;
                    localStorage.setItem("userId", this.userInfo.id)
                })
                .then(() => {
                    this.$nextTick(() => {
                        this.dataReady = true;
                    })
                })
        },
        login() {
            this.popupFlag.type = "login";
            this.popupFlag.flag = true;
        },
        openScanQues(name, id) {
            this.infoForScanQues = {name: name, id: id, flag: this.popupFlag, userId: this.userInfo.id};
            this.popupFlag.type = "scanQues";
            this.popupFlag.flag = true;
        },
    },
    components: {
        createTP,
        scanQues,
        exam,
        login
    },
    watch: {
        userInfo: {
            handler(newVal) {

            },
            deep: true,
            immediate: true
        }
    }
}
</script>

<template>

    <div class="standby-icon" style="display: none;">

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 288">
            <path fill="#649AD2"
                  d="M255.987 84.59c-.002-4.837-1.037-9.112-3.13-12.781c-2.054-3.608-5.133-6.632-9.261-9.023c-34.08-19.651-68.195-39.242-102.264-58.913c-9.185-5.303-18.09-5.11-27.208.27c-13.565 8-81.48 46.91-101.719 58.632C4.071 67.6.015 74.984.013 84.58C0 124.101.013 163.62 0 203.141c0 4.73.993 8.923 2.993 12.537c2.056 3.717 5.177 6.824 9.401 9.269c20.24 11.722 88.164 50.63 101.726 58.631c9.121 5.382 18.027 5.575 27.215.27c34.07-19.672 68.186-39.262 102.272-58.913c4.224-2.444 7.345-5.553 9.401-9.267c1.997-3.614 2.992-7.806 2.992-12.539c0 0 0-79.018-.013-118.539"/>
            <path fill="#004482"
                  d="m128.392 143.476l-125.4 72.202c2.057 3.717 5.178 6.824 9.402 9.269c20.24 11.722 88.164 50.63 101.726 58.631c9.121 5.382 18.027 5.575 27.215.27c34.07-19.672 68.186-39.262 102.272-58.913c4.224-2.444 7.345-5.553 9.401-9.267z"/>
            <path fill="#1A4674"
                  d="M91.25 164.863c7.297 12.738 21.014 21.33 36.75 21.33c15.833 0 29.628-8.7 36.888-21.576l-36.496-21.141z"/>
            <path fill="#01589C"
                  d="M255.987 84.59c-.002-4.837-1.037-9.112-3.13-12.781l-124.465 71.667l124.616 72.192c1.997-3.614 2.99-7.806 2.992-12.539c0 0 0-79.018-.013-118.539"/>
            <path fill="#FFF"
                  d="M249.135 148.636h-9.738v9.74h-9.74v-9.74h-9.737V138.9h9.737v-9.738h9.74v9.738h9.738zM128 58.847c31.135 0 58.358 16.74 73.17 41.709l.444.759l-37.001 21.307c-7.333-12.609-20.978-21.094-36.613-21.094c-23.38 0-42.333 18.953-42.333 42.332a42.13 42.13 0 0 0 5.583 21.003c7.297 12.738 21.014 21.33 36.75 21.33c15.659 0 29.325-8.51 36.647-21.153l.241-.423l36.947 21.406c-14.65 25.597-42.228 42.851-73.835 42.851c-31.549 0-59.084-17.185-73.754-42.707c-7.162-12.459-11.26-26.904-11.26-42.307c0-46.95 38.061-85.013 85.014-85.013m75.865 70.314v9.738h9.737v9.737h-9.737v9.74h-9.738v-9.74h-9.738V138.9h9.738v-9.738z"/>
        </svg>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 260">
            <path d="M239.184 106.203a64.72 64.72 0 0 0-5.576-53.103C219.452 28.459 191 15.784 163.213 21.74A65.586 65.586 0 0 0 52.096 45.22a64.72 64.72 0 0 0-43.23 31.36c-14.31 24.602-11.061 55.634 8.033 76.74a64.67 64.67 0 0 0 5.525 53.102c14.174 24.65 42.644 37.324 70.446 31.36a64.72 64.72 0 0 0 48.754 21.744c28.481.025 53.714-18.361 62.414-45.481a64.77 64.77 0 0 0 43.229-31.36c14.137-24.558 10.875-55.423-8.083-76.483m-97.56 136.338a48.4 48.4 0 0 1-31.105-11.255l1.535-.87l51.67-29.825a8.6 8.6 0 0 0 4.247-7.367v-72.85l21.845 12.636c.218.111.37.32.409.563v60.367c-.056 26.818-21.783 48.545-48.601 48.601M37.158 197.93a48.35 48.35 0 0 1-5.781-32.589l1.534.921l51.722 29.826a8.34 8.34 0 0 0 8.441 0l63.181-36.425v25.221a.87.87 0 0 1-.358.665l-52.335 30.184c-23.257 13.398-52.97 5.431-66.404-17.803M23.549 85.38a48.5 48.5 0 0 1 25.58-21.333v61.39a8.29 8.29 0 0 0 4.195 7.316l62.874 36.272l-21.845 12.636a.82.82 0 0 1-.767 0L41.353 151.53c-23.211-13.454-31.171-43.144-17.804-66.405zm179.466 41.695l-63.08-36.63L161.73 77.86a.82.82 0 0 1 .768 0l52.233 30.184a48.6 48.6 0 0 1-7.316 87.635v-61.391a8.54 8.54 0 0 0-4.4-7.213m21.742-32.69l-1.535-.922l-51.619-30.081a8.39 8.39 0 0 0-8.492 0L99.98 99.808V74.587a.72.72 0 0 1 .307-.665l52.233-30.133a48.652 48.652 0 0 1 72.236 50.391zM88.061 139.097l-21.845-12.585a.87.87 0 0 1-.41-.614V65.685a48.652 48.652 0 0 1 79.757-37.346l-1.535.87l-51.67 29.825a8.6 8.6 0 0 0-4.246 7.367zm11.868-25.58L128.067 97.3l28.188 16.218v32.434l-28.086 16.218l-28.188-16.218z"/>
        </svg>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 256">
            <path fill="#93D500"
                  d="M67.651 147.204H.101c.011.329.02.66.038.99c.028.635.074 1.268.112 1.903c.019.272.03.544.05.814c.053.735.117 1.467.184 2.198l.045.492q.118 1.222.263 2.434q.008.119.025.235a100 100 0 0 0 .352 2.646a113 113 0 0 0 3.49 15.962q.012.033.02.066q.366 1.238.762 2.462q.025.072.045.144q.021.072.046.144c.24.738.491 1.474.743 2.212c.066.185.128.372.196.558q.34.956.695 1.913q.166.43.327.863l.617 1.58q.238.592.487 1.186q.255.615.516 1.234c.215.503.44 1.003.66 1.504q.2.449.4.893q.414.903.842 1.799c.094.192.183.384.279.576q.498 1.031 1.012 2.045q.084.157.16.314a111 111 0 0 0 1.237 2.342c.084.155.178.304.262.457l57.692-34.755l.212-.128a46 46 0 0 1-4.219-15.083"/>
            <path fill="#4D5A31"
                  d="m84.253 178.215l-.162.162L36.51 225.96c.244.228.487.46.738.68c.443.403.896.803 1.346 1.196q.348.313.695.615c.54.466 1.083.921 1.625 1.376l.439.366a108 108 0 0 0 2.096 1.684c.674.53 1.355 1.047 2.043 1.568q.044.026.077.057a114 114 0 0 0 8.902 6.017c.105.067.21.128.318.195q.873.524 1.753 1.035a257 257 0 0 0 2.096 1.186a146 146 0 0 0 2.118 1.14c1.73.906 3.49 1.747 5.264 2.556l1.688-4.1l23.931-58.117l.09-.215a46 46 0 0 1-7.476-4.984"/>
            <path fill="#6BA43A"
                  d="M79.298 173.475a44 44 0 0 1-1.483-1.749a47 47 0 0 1-1.234-1.593c-.455-.617-.9-1.236-1.321-1.87a49 49 0 0 1-1.235-1.926l-57.764 34.798a113 113 0 0 0 2.756 4.329l.094.149l.034.052q.046.07.092.144l.009.014c.075.114.153.224.23.338l.014.02l.007.01a114 114 0 0 0 3.097 4.365l.07.091l.07.09q.688.919 1.403 1.828q.09.12.19.235q.733.94 1.494 1.856q.18.216.361.437c.457.546.914 1.09 1.38 1.63c.2.23.407.46.608.69c.398.452.791.902 1.198 1.348c.222.244.452.491.679.736c.103.112.203.221.308.333q.444.48.892.958c.118.126.244.249.365.375a98 98 0 0 0 1.598 1.636l47.651-47.651a41 41 0 0 1-1.563-1.673"/>
            <path fill="#4D5A31"
                  d="M142.46 178.19q-.784.635-1.592 1.234l.119.199l34.743 57.673a109 109 0 0 0 4.754-3.273a115 115 0 0 0 9.752-8.06l-47.586-47.586z"/>
            <path fill="#93D500"
                  d="m170.681 237.769l-1.179-1.957l-32.43-53.833c-.656.395-1.328.752-1.998 1.113q-1.013.543-2.048 1.03a46.05 46.05 0 0 1-19.728 4.464a46 46 0 0 1-13.123-1.915c-.729-.217-1.44-.503-2.16-.759c-.72-.254-1.448-.473-2.157-.766l-23.915 58.078l-.937 2.276l-.802 1.95l-.004.009q.093.036.187.07c.066.028.13.049.197.076h.002q.004.001.004.003q.025.008.046.018c.565.23 1.134.43 1.7.651c.711.277 1.422.558 2.135.818c.363.133.725.288 1.088.416h.002a114 114 0 0 0 23.127 5.536c.308.036.614.08.923.123c.322.037.647.069.969.105c.608.069 1.214.14 1.824.2q.225.016.452.038q1.123.107 2.238.187c.253.019.51.03.76.048a93 93 0 0 0 1.962.115c.4.022.8.034 1.202.048c.519.018 1.035.038 1.559.054c.747.019 1.501.026 2.253.028q.267.001.53.007c6.297 0 12.59-.524 18.816-1.568q.156-.025.316-.048c.658-.114 1.316-.238 1.974-.359c.375-.073.752-.144 1.122-.217l1.155-.242a97 97 0 0 0 1.924-.423c.114-.025.23-.048.347-.08a114 114 0 0 0 27.19-10.138l.002-.003c.563-.297 1.111-.635 1.671-.939c.667-.366 1.33-.743 1.993-1.122c.46-.263.923-.505 1.378-.777l.002-.002l.014-.01h.002l.021-.011l.01-.007l-.085-.144l.084.144l.014-.007l.02-.011l.076-.046l.445-.267zM84.28 107.078a47 47 0 0 1 1.593-1.234l-.119-.199l-34.74-57.673a106 106 0 0 0-4.766 3.282a114 114 0 0 0-9.74 8.05l47.585 47.584z"/>
            <path fill="#4D5A31"
                  d="M33.207 62.47c-.541.542-1.053 1.102-1.581 1.65c-.528.55-1.065 1.096-1.582 1.653a114 114 0 0 0-9.626 11.93c-.14.195-.279.398-.416.597a112 112 0 0 0-1.947 2.927q-.181.276-.357.551C6.753 98.948.89 118.423.101 138.062c-.03.76-.046 1.524-.062 2.285S0 141.872 0 142.633h67.393c0-.764.07-1.522.11-2.286c.039-.763.05-1.526.125-2.285a45.74 45.74 0 0 1 10.164-24.544c.48-.585 1.021-1.133 1.536-1.698c.512-.564.987-1.152 1.533-1.695zM172.26 45.744c-.09-.057-.187-.112-.278-.167a94 94 0 0 0-1.79-1.063c-.347-.201-.695-.395-1.044-.594c-.352-.197-.7-.393-1.054-.585q-.912-.501-1.83-.987l-.288-.151a113 113 0 0 0-12.477-5.588a113.8 113.8 0 0 0-25.428-6.379l-.948-.128c-.318-.039-.633-.07-.948-.105c-.61-.07-1.218-.14-1.831-.199c-.17-.016-.34-.027-.512-.046c-.724-.066-1.453-.13-2.178-.182c-.281-.021-.567-.037-.848-.053c-.621-.041-1.25-.085-1.872-.112c-.333-.018-.662-.027-.992-.039l-.002 67.293v.263a46.8 46.8 0 0 1 10.234 2.228l49.718-49.718a110 110 0 0 0-5.631-3.688"/>
            <path fill="#6BA43A"
                  d="M111.086 29.311c-.76.016-1.524.019-2.285.048c-4.768.192-9.526.68-14.245 1.47l-.311.052c-.663.115-1.319.236-1.977.36q-.56.103-1.12.214q-.583.117-1.161.242q-.96.199-1.92.42q-.172.04-.35.079a114 114 0 0 0-27.192 10.142h-.002c-.56.297-1.106.633-1.664.94c-.667.365-1.33.742-1.993 1.122c-.491.283-.992.544-1.48.836l-.017.01h-.002l-.103.059c-.128.078-.26.142-.388.22l.007.01l1.179 1.96l33.607 55.792c.656-.396 1.328-.755 1.998-1.113a45 45 0 0 1 2.045-1.031c4.8-2.286 9.9-3.703 15.086-4.228a45 45 0 0 1 2.286-.18c.76-.04 1.522-.079 2.285-.079l.003-67.39c-.764 0-1.525.032-2.286.045"/>
            <path fill="#4D5A31"
                  d="M226.602 137.06q-.049-.906-.11-1.816c-.018-.302-.034-.601-.06-.907q-.076-1.068-.176-2.135c-.013-.185-.032-.368-.048-.553q-.116-1.193-.253-2.384q-.014-.096-.023-.192l-.012-.091q-.158-1.286-.34-2.57a113 113 0 0 0-3.494-16.014q-.016-.053-.033-.1q-.365-1.219-.75-2.43c-.033-.104-.07-.212-.102-.32c-.24-.728-.482-1.453-.734-2.18q-.105-.29-.208-.59q-.332-.941-.683-1.88q-.168-.45-.343-.894q-.296-.779-.605-1.55q-.247-.614-.499-1.22q-.247-.601-.502-1.202q-.333-.769-.672-1.533q-.19-.43-.389-.864a146 146 0 0 0-.852-1.822c-.09-.182-.176-.37-.265-.553a134 134 0 0 0-1.024-2.07l-.149-.286c-.388-.756-.786-1.515-1.19-2.263c-.017-.025-.028-.054-.044-.08a113 113 0 0 0-6.45-10.462l-49.733 49.735a47 47 0 0 1 2.226 10.232h67.558c-.016-.34-.025-.674-.041-1.005"/>
            <path fill="#6BA43A"
                  d="M159.346 142.633c0 .763-.071 1.522-.11 2.285c-.037.763-.05 1.527-.126 2.286a45.76 45.76 0 0 1-10.16 24.545c-.48.585-1.023 1.134-1.537 1.698c-.512.565-.987 1.152-1.533 1.696l47.653 47.652c.542-.542 1.052-1.102 1.58-1.653s1.065-1.095 1.579-1.652a114 114 0 0 0 9.654-11.967c.116-.164.226-.327.338-.489c.354-.51.7-1.024 1.047-1.538c.304-.46.608-.919.902-1.383c.147-.221.293-.452.435-.674c10.929-17.161 16.777-36.615 17.563-56.238c.03-.76.046-1.524.062-2.285s.039-1.522.039-2.286h-67.386z"/>
            <path fill="#424143"
                  d="M246.755 9.247c-12.33-12.33-32.321-12.33-44.649 0c-9.836 9.835-11.802 24.537-5.944 36.344l-68.771 68.773c-11.807-5.855-26.51-3.892-36.346 5.942c-12.33 12.33-12.328 32.32 0 44.65c12.332 12.33 32.323 12.326 44.653-.001c9.834-9.835 11.798-24.537 5.94-36.346l68.771-68.771c11.809 5.855 26.509 3.892 36.343-5.944c12.33-12.324 12.33-32.317.003-44.647"/>
        </svg>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 256">
            <defs>
                <linearGradient id="IconifyId1908e5d4a4c2715e61363" x1="-46.686%" x2="90.514%" y1="50%"
                                y2="50%">
                    <stop offset="0%" stop-color="#21D789"/>
                    <stop offset="100%" stop-color="#07C3F2"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61364" x1="-19.16%" x2="105.922%" y1="105.481%"
                                y2="-7.577%">
                    <stop offset="1%" stop-color="#FCF84A"/>
                    <stop offset="11%" stop-color="#A7EB62"/>
                    <stop offset="21%" stop-color="#5FE077"/>
                    <stop offset="27%" stop-color="#32DA84"/>
                    <stop offset="31%" stop-color="#21D789"/>
                    <stop offset="60%" stop-color="#21D789"/>
                    <stop offset="69%" stop-color="#20D68C"/>
                    <stop offset="76%" stop-color="#1ED497"/>
                    <stop offset="83%" stop-color="#19D1A9"/>
                    <stop offset="90%" stop-color="#13CCC2"/>
                    <stop offset="97%" stop-color="#0BC6E1"/>
                    <stop offset="100%" stop-color="#07C3F2"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61365" x1="42.23%" x2="61.179%" y1="115.967%"
                                y2="22.253%">
                    <stop offset="0%" stop-color="#21D789"/>
                    <stop offset="16%" stop-color="#24D888"/>
                    <stop offset="30%" stop-color="#2FD985"/>
                    <stop offset="43%" stop-color="#41DC80"/>
                    <stop offset="55%" stop-color="#5AE079"/>
                    <stop offset="67%" stop-color="#7AE46F"/>
                    <stop offset="79%" stop-color="#A1EA64"/>
                    <stop offset="90%" stop-color="#CFF157"/>
                    <stop offset="100%" stop-color="#FCF84A"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61366" x1="-9.711%" x2="118.641%" y1="144.55%"
                                y2="8.292%">
                    <stop offset="0%" stop-color="#21D789"/>
                    <stop offset="9%" stop-color="#23D986"/>
                    <stop offset="17%" stop-color="#2ADE7B"/>
                    <stop offset="25%" stop-color="#36E669"/>
                    <stop offset="27%" stop-color="#3BEA62"/>
                    <stop offset="35%" stop-color="#47EB61"/>
                    <stop offset="49%" stop-color="#67ED5D"/>
                    <stop offset="69%" stop-color="#9AF156"/>
                    <stop offset="92%" stop-color="#E0F64D"/>
                    <stop offset="100%" stop-color="#FCF84A"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61367" x1="105.92%" x2="-8.04%" y1="50.481%"
                                y2="49.366%">
                    <stop offset="39%" stop-color="#FCF84A"/>
                    <stop offset="46%" stop-color="#ECF74C"/>
                    <stop offset="61%" stop-color="#C1F451"/>
                    <stop offset="82%" stop-color="#7EEF5A"/>
                    <stop offset="100%" stop-color="#3BEA62"/>
                </linearGradient>
            </defs>
            <path fill="url(#IconifyId1908e5d4a4c2715e61363)"
                  d="m179.493 40.4l74.8 62.213l-26.933 54.8l-45.093-12.506h-39.014z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61364)"
                  d="m104.133 80.8l-14.48 76.613l-1.386 26.027l-36.507 15.813L0 204.827l15.707-165.52L109.493 0l57.787 37.893z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61365)"
                  d="m104.133 80.8l7.04 147.627L87.787 256L0 204.827L72.08 97.413z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61366)" d="M200.72 70.027h-88.693L190.4 0z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61367)"
                  d="m256 229.013l-78.08 26.507l-103.973-29.28L104.133 80.8l12.054-10.773l63.306-5.947l-5.733 63.573l50.347-19.52z"/>
            <path d="M48 48h160v160H48z"/>
            <path fill="#FFF"
                  d="M67.947 177.76h60v10h-60zM68 68h24.533c14.15 0 22.786 8.311 22.958 20.354l.002.526c0 13.867-10.8 21.067-24.24 21.067h-9.92v17.973H68zm23.627 30.213c6.475 0 10.321-3.788 10.45-8.806l.003-.42c0-5.92-4.107-9.094-10.667-9.094h-10.08v18.32zm31.013-.053V98a30.427 30.427 0 0 1 31.227-30.987a30.9 30.9 0 0 1 23.626 9.227l-8.373 9.68a22.2 22.2 0 0 0-15.333-6.773c-9.995 0-17.225 8.214-17.384 18.325L136.4 98c0 10.267 7.12 18.827 17.387 18.827c6.23 0 10.256-2.204 14.483-5.87l.636-.561q.32-.286.64-.583l8.374 8.454a30.56 30.56 0 0 1-24.56 10.666a30.267 30.267 0 0 1-30.72-30.773"/>
        </svg>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 255">
            <defs>
                <linearGradient id="IconifyId1908e5d4a4c2715e61373" x1="12.959%" x2="79.639%" y1="12.039%"
                                y2="78.201%">
                    <stop offset="0%" stop-color="#387EB8"/>
                    <stop offset="100%" stop-color="#366994"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61374" x1="19.128%" x2="90.742%" y1="20.579%"
                                y2="88.429%">
                    <stop offset="0%" stop-color="#FFE052"/>
                    <stop offset="100%" stop-color="#FFC331"/>
                </linearGradient>
            </defs>
            <path fill="url(#IconifyId1908e5d4a4c2715e61373)"
                  d="M126.916.072c-64.832 0-60.784 28.115-60.784 28.115l.072 29.128h61.868v8.745H41.631S.145 61.355.145 126.77c0 65.417 36.21 63.097 36.21 63.097h21.61v-30.356s-1.165-36.21 35.632-36.21h61.362s34.475.557 34.475-33.319V33.97S194.67.072 126.916.072M92.802 19.66a11.12 11.12 0 0 1 11.13 11.13a11.12 11.12 0 0 1-11.13 11.13a11.12 11.12 0 0 1-11.13-11.13a11.12 11.12 0 0 1 11.13-11.13"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61374)"
                  d="M128.757 254.126c64.832 0 60.784-28.115 60.784-28.115l-.072-29.127H127.6v-8.745h86.441s41.486 4.705 41.486-60.712c0-65.416-36.21-63.096-36.21-63.096h-21.61v30.355s1.165 36.21-35.632 36.21h-61.362s-34.475-.557-34.475 33.32v56.013s-5.235 33.897 62.518 33.897m34.114-19.586a11.12 11.12 0 0 1-11.13-11.13a11.12 11.12 0 0 1 11.13-11.131a11.12 11.12 0 0 1 11.13 11.13a11.12 11.12 0 0 1-11.13 11.13"/>
        </svg>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 256">
            <defs>
                <linearGradient id="IconifyId1908e5d4a4c2715e61574" x1="0%" x2="115.015%" y1="50%" y2="50%">
                    <stop offset="0%" stop-color="#FF318C"/>
                    <stop offset="15%" stop-color="#FB348C"/>
                    <stop offset="28%" stop-color="#F03C8C"/>
                    <stop offset="42%" stop-color="#DE4A8C"/>
                    <stop offset="54%" stop-color="#C45D8B"/>
                    <stop offset="67%" stop-color="#A2778B"/>
                    <stop offset="79%" stop-color="#79958A"/>
                    <stop offset="91%" stop-color="#49B98A"/>
                    <stop offset="100%" stop-color="#21D789"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61575" x1="53.816%" x2="43.444%" y1="17.257%"
                                y2="151.488%">
                    <stop offset="9%" stop-color="#21D789"/>
                    <stop offset="90%" stop-color="#009AE5"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61576" x1="93.049%" x2="-9.597%" y1="9.981%"
                                y2="113.191%">
                    <stop offset="9%" stop-color="#21D789"/>
                    <stop offset="90%" stop-color="#009AE5"/>
                </linearGradient>
                <linearGradient id="IconifyId1908e5d4a4c2715e61577" x1="32.388%" x2="91.688%" y1="46.039%"
                                y2="52.244%">
                    <stop offset="9%" stop-color="#21D789"/>
                    <stop offset="90%" stop-color="#009AE5"/>
                </linearGradient>
            </defs>
            <path fill="url(#IconifyId1908e5d4a4c2715e61574)" d="M92.027 100.107L97.573 0l58.214 32.267z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61575)"
                  d="M92.027 100.107L97.573 0l-73.92 46.587L0 188.213z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61576)"
                  d="M250.907 76.72L217.973 9.76l-62.186 22.507l-63.76 67.84L0 188.213l83.013 60.427l104.347-94.107z"/>
            <path fill="url(#IconifyId1908e5d4a4c2715e61577)"
                  d="M208 146.773V208H107.467l44.186 34.187l64 13.813L256 164.667z"/>
            <path d="M48 48h160v160H48z"/>
            <path fill="#FFF"
                  d="M67.947 177.76h60v10h-60zm60.186-109.92h13.334v49.04h26.266V128h-39.6zM63.676 98.815l.004-.655a30.773 30.773 0 0 1 31.547-31.307a31.23 31.23 0 0 1 23.84 9.334l-8.4 9.786a22.35 22.35 0 0 0-15.494-6.826c-10.073 0-17.356 8.266-17.517 18.481l-.003.532c0 10.373 7.174 19.013 17.52 19.013c6.934 0 11.147-2.666 16-7.093l8.32 8.587a30.93 30.93 0 0 1-24.826 10.666a30.533 30.533 0 0 1-30.99-30.518"/>
        </svg>

    </div>
&lt;!&ndash;    <router-link to="/login">Login</router-link>&ndash;&gt;
&lt;!&ndash;    <router-view></router-view>&ndash;&gt;
    <div class="popup" id="popup" :style="{'overflow-y': popupFlag.overflow}" v-show="popupFlag.flag">

        <div class="control-btn">

            <div class="icon-wrapper back-icon">

                <svg @click="popupFlag.back = true" width="24" height="24" viewBox="0 0 20 20">
                    <title>back</title>
                    <rect x="2" y="2" width="16" height="16" stroke="white" rx="2" ry="2" fill="#ccc" opacity="0"/>
                    <line x1="14" y1="4" x2="4" y2="10" stroke-width="2" stroke="white"/>
                    <line x1="14" y1="16" x2="4" y2="10" stroke-width="2" stroke="white"/>
                </svg>

            </div>

            <div class="icon-wrapper close-icon">

                <svg @click="popupFlag.flag = false" viewBox="0 0 20 20" width="24" height="24">
                    <title>Close</title>
                    <rect x="2" y="2" width="16" height="16" stroke="white" rx="2" ry="2" fill="#ccc" opacity="0"/>
                    <line x1="4" y1="4" x2="16" y2="16" stroke="white" stroke-width="2"/>
                    <line x1="16" y1="4" x2="4" y2="16" stroke="white" stroke-width="2"/>
                </svg>

            </div>

        </div>


        <login v-if="loginFlag" @message-sent="handleMsg"/>
        <createTP v-else-if="createTPFlag" :message="{flag: popupFlag, user: userInfo}" @message-sent="handleMsg" />
        <scanQues v-else-if="scanQuesFlag" :message="infoForScanQues" @message-sent="handleMsg" />
        <exam v-else-if="examFlag" :message="{id: examTPid, flag: popupFlag, userId: userInfo.id}" @message-sent="handleMsg" />

    </div>

    <div id="root">

        <header class="page-header">

            <div class="logo">

                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 286"><defs><linearGradient x1="0%" y1="50%" x2="100%" y2="50%" id="IconifyId19082901379fdac601560"><stop stop-color="#52F2C9" offset="0%"/><stop stop-color="#52F2C9" offset="9.876%"/><stop stop-color="#8573E2" offset="100%"/></linearGradient></defs><path d="M22.37 285.192c-3.854 0-7.706-1.016-11.214-3.048C4.171 278.096 0 270.859 0 262.786V21.908c0-7.887 4.073-14.96 10.895-18.92c6.822-3.96 14.983-3.985 21.832-.071l155.474 88.847a7.995 7.995 0 0 1-7.933 13.88L24.795 16.799c-2.658-1.518-4.994-.493-5.876.019c-.881.512-2.931 2.032-2.931 5.09v240.879c0 3.32 2.226 4.969 3.183 5.523c.957.555 3.494 1.668 6.375.015l200.493-114.952h-23.111a7.995 7.995 0 0 1-7.994-7.995v-5.33h-9.992v18.154a7.995 7.995 0 0 1-7.994 7.994h-25.314a7.995 7.995 0 0 1-7.994-7.994v-33.308h-10.242v56.373a7.994 7.994 0 0 1-7.994 7.994h-26.23a7.995 7.995 0 0 1-7.994-7.994V101.41h-9.825v108.583a7.995 7.995 0 0 1-7.995 7.994H46.714a7.994 7.994 0 0 1-7.994-7.994V65.77h-3.331a7.994 7.994 0 1 1 0-15.988h11.325a7.994 7.994 0 0 1 7.994 7.994V202h10.658V93.417a7.994 7.994 0 0 1 7.994-7.994h25.814a7.994 7.994 0 0 1 7.994 7.994v79.855h10.242v-56.373a7.995 7.995 0 0 1 7.994-7.994h26.23a7.994 7.994 0 0 1 7.994 7.994v33.308h9.326v-18.153a7.994 7.994 0 0 1 7.994-7.994h25.98a7.994 7.994 0 0 1 7.994 7.994v5.329h34.144c5.02 0 9.261 3.26 10.552 8.11c1.292 4.852-.767 9.789-5.123 12.285L33.498 282.194c-3.487 1.999-7.308 2.998-11.128 2.998" fill="url(#IconifyId19082901379fdac601560)"/></svg>
                <h1 class="logo-text">Exam Platfrom</h1>

            </div>

            <div class="user-info">

                <span class="user-name" >{{ userInfo.name }}</span>

                <div class="user-icon" @click="login">

                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 650 650" preserveAspectRatio="xMidYMid meet">
                        <title>Login or Register</title>
                        <g transform="translate(0,650) scale(0.1,-0.1)" fill="black">
                            <path d="M2655 6465 c-533 -102 -1000 -314 -1435 -651 -148 -114 -420 -386 -534 -534 -360 -464 -589 -995 -670 -1551 -23 -152 -23 -796 0 -948 81 -556 310 -1087 670 -1551 114 -148 386 -420 534 -534 467 -362 977 -582 1560 -673 167 -26 763 -26 930 0 583 91 1093 311 1560 673 148 114 420 386 534 534 362 467 582 977 673 1560 15 95 18 177 18 465 0 288 -3 370 -18 465 -91 583 -311 1093 -673 1560 -114 148 -386 420 -534 534 -441 341 -927 560 -1459 655 -105 19 -152 21 -575 20 -438 -1 -467 -2 -581 -24z m820 -1044 c190 -43 370 -136 513 -267 254 -231 390 -586 353 -923 -28 -263 -126 -473 -309 -663 -273 -284 -674 -399 -1055 -304 -477 120 -812 533 -834 1027 -24 530 333 1003 847 1124 137 32 353 35 485 6z m-1018 -2359 c209 -155 398 -256 570 -303 97 -26 283 -36 378 -20 195 34 423 147 671 333 51 37 97 68 103 68 6 0 44 -16 84 -36 220 -111 391 -269 550 -507 174 -260 317 -653 329 -902 l3 -70 -1889 -3 c-1040 -1 -1893 1 -1897 5 -12 13 10 180 41 308 110 458 371 869 692 1086 57 39 224 128 240 129 5 0 61 -39 125 -88z"/>
                        </g>
                    </svg>

                </div>

            </div>

        </header>

        <div class="wark-table">

            <div class="sider-menu">

                <ul class="menu">

                    <li class="menu-item" @click="showFlag = 'item'">

                        <span role="img" aria-hidden="true">

                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 -50 256 256" focusable="false">
                                <title>testPaper</title>
                                <g>
                                    <title>Layer 1</title>
                                    <ellipse ry="100" rx="100" id="svg_6" cy="128" cx="128" stroke-width="10" stroke="#ffffff" fill="#ffffff"/>
                                    <line id="svg_8" y2="128" x2="165.335" y1="128" x1="89.335" stroke-width="10" stroke="#000000" fill="none"/>
                                    <line id="svg_9" y2="128" x2="165.335" y1="128" x1="89.335" stroke-width="10" stroke="#000000" fill="none"/>
                                    <line id="svg_10" y2="152" x2="165.335" y1="152" x1="89.335" stroke-width="10" stroke="#000000" fill="none"/>
                                    <line id="svg_11" y2="177" x2="165.335" y1="177" x1="89.335" stroke-width="10" stroke="#000000" fill="none"/>
                                    <line id="svg_12" y2="208" x2="68" y1="48" x1="68" stroke-width="20" stroke="#000000" fill="none"/>
                                    <line id="svg_13" y2="208" x2="188" y1="208" x1="68" stroke-width="20" stroke="#000000" fill="none"/>
                                    <line id="svg_14" y2="98" x2="188" y1="203" x1="188" stroke-width="20" stroke="#000000" fill="none"/>
                                    <line id="svg_15" y2="48" x2="148" y1="48" x1="68" stroke-width="20" stroke="#000000" fill="none"/>
                                    <path d="m145.33499,48.99999c2,0 2,0 3,0c1,0 1,0 2,0c1,0 0.69344,0.45881 2,1c0.92387,0.38268 2,1 3,1c0,0 0.15224,-0.76537 2,0c1.30656,0.54119 1.29289,1.29289 2,2c0.70711,0.70711 2,0 3,1c1,1 2,1 3,1c0,0 0.82375,1.48626 3,2c0.97325,0.22975 2.07613,0.61732 3,1c1.30656,0.54119 1.69344,2.45881 3,3c0.92387,0.38268 1,0 3,2c0,0 0.29289,1.2929 1,2c0.70711,0.70711 0.61731,0.07612 1,1c0.5412,1.30656 2,1 2,1c0,1 1.4588,1.69344 2,3c0.38269,0.92388 0,1 0,3c0,1 0,2 0,2c1,1 1,2 1,2c1,2 1,3 1,4c0,0 0,2 1,2c0,0 0.4588,0.69344 1,2c0.38269,0.92388 0,2 0,2c0,1 0,2 0,2c1,1.99999 1,1.99999 2,4.99999l0,1" id="svg_18" stroke-width="20" stroke="#000000" fill="none"/>
                                    <path d="m138.33499,54.99999c3,1 3.07613,1.61732 4,2c1.30656,0.54119 1,2 1,2c1,0 1,1 2,2c0,0 2,2 2,2c0,1 -0.38269,2.07612 0,3c0.5412,1.30656 2,1 2,2c0,1 -0.38269,1.07612 0,2c0.5412,1.30656 1,2 2,3c0,0 0,1 0,2c0,0 0,1 1,2c0,0 0,1 0,2c0,1 1,1 1,2c0,0 0,1 0,2c0,0 0,1 0,2c0,0 0,1 0,2c0,2.99999 0,3.99999 0,4.99999c0,1 1,1 3,1c1,0 2,0 3,0c0,0 2,0 3,0c1,0 2,0 3,0c1,0 2.07613,-0.38268 3,0c1.30656,0.5412 3,1 3,1c1,0 3,0 4,0c1,0 2,1 3,1l1,0l0,0l1,0" id="svg_19" stroke-width="20" stroke="#000000" fill="none"/>
                                </g>
                            </svg>

                        </span>

                        <p style="margin-left: 10px;">套卷</p>

                    </li>

                </ul>

            </div>

            <div class="widow">

                <div class="item-table" v-if="showFlag === 'item'">

                    <div class="item-wrapper">

                        <div class="item item-image" v-for="(item, index) in userInfo.TPs" :key="index" @click="openScanQues(item.name, item.id, item)" :style="{ 'background-image': `url(${item.fileData})` }">

                            <div class="item-text">

                                <p class="itme-name">{{ item.name }}</p>
                                <p class="itme-desc">{{ item.desc }}</p>

                            </div>

                        </div>

                        <div class="item" @click="popupFlag['type'] = 'createTP'; popupFlag['flag'] = true;">

                            <svg role="img" xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 24 24" aria-labelledby="addIconTitle">
                                <title id="addIconTitle">Add</title>
                                <line x1="12" y1="6" x2="12" y2="18" stroke-width="1" stroke="black" stroke-linecap="round"  stroke-linejoin="round" opacity="0.7"></line>
                                <line x1="6" y1="12" x2="18" y2="12" stroke-width="1" stroke="black" stroke-linecap="round" stroke-linejoin="round" opacity="0.7"></line>
                            </svg>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>
</template>

<style>
body {
    background-color: #202020;
    overflow: hidden;
}

svg {
    overflow: visible;
}

.user-info {
    float: right;
    cursor: pointer;
    display: flex;
    align-items: center;
}

.user-name {
    font-weight: bold;
    font-size: 25px;
    margin-right: 10px;
    color: #ededed;
}

.popup {
    position: absolute;
    top: 50%; /* 从顶部开始，偏移50%的父元素高度 */
    left: 50%; /* 从左侧开始，偏移50%的父元素宽度 */
    transform: translate(-50%, -50%); /* 相对于元素自身的中心点进行移动，以使其完全居中 */
    width: 100%;
    height: 100%;
    border-radius: 5px;
    background-color: #474747;
    z-index: 1;
    flex-direction: column;
    border: 2px solid #171717;
}

.control-btn {
    position: absolute;
    float: right;
    display: flex;
    flex-direction: row;
    right: 0;
}

.icon-wrapper {
    border-radius: 5px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.close-icon:hover {
    background-color: red;
}

.back-icon:hover {
    border: 1px solid white;
}

.page-header {
    background-color: #3289ff;
    padding: 0 24px;
    min-height: 60px;
    border-radius: 0 0 8px 8px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
}

.logo {
    display: flex;
    align-items: center;
}

.logo-text {
    font-size: 24px;
    color: honeydew;
    margin-left: 10px;
}

.wark-table {
    display: flex;
    flex-direction: row;
    height: 100vh;
}

.sider-menu {
    flex: 1;
    background-color: #092035;
    border-radius: 8px;
    margin: 10px 5px 0 0;
}

.menu {
    list-style: none;
    padding-inline-start: 0;
    margin-block-start: 5px;
    margin-block-end: 0;
    height: calc(100% - 40px);
}

.menu-item {
    list-style: none;
    color: #9e9e9e;
    margin: 0 5px;
    border-radius: 4px;
    height: 6%;
    text-align: left;
    align-content: center;
    padding: 0 0 0 10px;
    font-weight: bold;
    font-size: 20px;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: row;
    align-items: center;
    cursor: pointer;
}

.menu-item:hover {
    background-color: #1a2f49;
    color: #37eff3;
}

.widow {
    flex: 3;
    background-color: #474747;
    border-radius: 8px;
    margin: 10px 0 0 5px;
}

.item-table {
    background-color: #aeaeae;
    border-radius: 8px;
    margin: 5px;
}

.item-wrapper {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    gap: 10px;
}

.item {
    width: calc(19% - 10px);
    height: 150px;
    background-color: lightblue;
    display: flex;
    justify-content: center;
    border-radius: 8px;
    margin: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    flex-direction: column;
    align-items: center;
}

.item:hover {
    filter: brightness(1.1);
}

.item-text {
    padding: 0 10px;
}

.itme-name {
    font-size: 20px;
}

.itme-desc {
    font-size: 13px;
}

.item-image {
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
}

</style>
