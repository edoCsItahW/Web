<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->

<script>
export default {
    data() {
        return {}
    },
    methods: {
        check(event) {
            const checkeds = document.getElementsByClassName("checked");

            if (event.target.classList.contains("right") || event.target.classList.contains("wrong")) return;

            if (checkeds && checkeds.length > 0) {
                if (checkeds[0] !== event.target) checkeds[0].classList.remove("checked");
            }

            let target = event.target;

            if (target.nodeName !== 'A') {
                while (target.nodeName !== 'A') {
                    target = target.parentNode;
                }
            }

            target.classList.add("checked");
        },
        checkAnswer() {
            const options = document.getElementsByClassName("std-link")

            for (let elem of options) {
                elem.classList.remove("checked");

                if (elem.getAttribute("name") === this.message.quesInfo.answer) elem.classList.add("right");
                else elem.classList.add("wrong");
            }
        },
        clearOprions() {
            const options = document.getElementsByClassName("std-link")

            for (let elem of options) {
                elem.classList.remove("right");
                elem.classList.remove("wrong");
            }

        },
        nextQuestion() {
            this.clearOprions()
            this.$emit("message-sent", {type: "nextQues", data: null})
        }
    },
    props: {
        message: {
            cnName: String,
            quesInfo: Object
        }
    },
    watch: {}
}
</script>

<template>
    <div class="root">

        <h2>{{ message.cnName }}</h2>

        <div class="right-shift">

            <span><b style="font-size: 18px;">{{ message.quesInfo.id }}. </b>{{ message.quesInfo.question }}</span>

            <ul class="option-warpper" style="list-style: none;">

                <li v-for="(content, key) in message.quesInfo.options">

                    <a class="std-link option" href="javascript:void(0);" @click="check" :name="key">

                        <span><b style="font-size: 18px;">{{ key }}. </b>{{ content }}</span>

                    </a>

                </li>

            </ul>

            <div class="btn-block">

                <a class="std-btn" href="javascript:void(0);" @click="checkAnswer">
                    <span>Submit</span>
                </a>

                <a class="std-btn" href="javascript:void(0);" @click="nextQuestion">
                    <span>Next</span>
                </a>

            </div>

        </div>

    </div>
</template>

<style>
.option {
    margin: 10px;
}

.checked {
    background-color: #52a3ff;
}

.right {
    background-color: #00cc00;
}

.wrong {
    background-color: #ff0000;
}

</style>