<script>
import {$, request} from "../../../../jsPackage/src/comFunc/index.js"


const appUrl = location.href + "api/"


export default {
    data() {
        return {
            userInfo: {
                name: '',
                password: '',
                captcha: ''
            },
            captcha: null,
            nowCaptcha: [],
            mathKit: {
                vvec: (start, end) => {return [end - start, 0]},
                hvec: (start, end) => {return [0, end - start]},
                dot: (vec1, vec2) => {return vec1[0] * vec2[0] + vec1[1] * vec2[1]},
                len: (vec) => {return Math.sqrt(vec[0] ** 2 + vec[1] ** 2)},
                cos: (vec1, vec2) => { return this.mathKit.dot(vec1, vec2) / (this.mathKit.len(vec1) * this.mathKit.len(vec2)); },
                sin: (vec1, vec2=null) => {
                    if (vec2) return Math.sqrt(1 - this.mathKit.cos(vec1, vec2) ** 2);
                    else return Math.sqrt(1 - vec1 ** 2);
                },
                dirCos: (startX, startY, endX, endY) => {
                    const vec1 = [endX - startX, endY - startY];
                    const vec2 = this.mathKit.vvec(startX, endX);
                    return this.mathKit.cos(vec1, vec2);
                },
                dirTran: (startX, startY, endX, endY) => {
                    const cosRes = this.mathKit.dirCos(startX, startY, endX, endY);
                    return [cosRes, this.mathKit.sin(cosRes)]
                }
            },
            flag: false,
        }
    },
    created() {
        this.getCaptcha()
    },
    methods: {
        login() {
            if (this.flag && this.nowCaptcha.join('') !== this.userInfo.captcha) alert("验证码错误");

            request(appUrl, "", {type: this.flag ? "register" : "login", name: this.userInfo.name, password: $.toHash(this.userInfo.password), ip: location.href}, "POST")
                .then(res => {
                    if (res.code === 200) {
                        if (this.flag) {
                            this.flag = false;
                            const pt = document.getElementById("password-type");
                            const rt = document.getElementById("register-type");

                            pt.classList.add("selected");
                            rt.classList.remove("selected");
                        }
                        else {
                            this.$emit("message-sent", {type: "login", data: res.data});
                            this.$emit("message-sent", {type: "closePopup", data: false});

                        }
                    }
                    else {
                        console.error(`Login failed: ${res.msg}(${res.code})!`);
                        alert(res.msg)
                    }
                })
        },
        randomColor() {
            return `rgb(${Array.from({length: 3}, () => Math.floor(Math.random() * 256)).join(',')})`
        },
        updateCaptcha() {
            let num = [];

            this.getCaptcha();
            this.drawCaptcha(this.nowCaptcha);
            let ctx = $.id("captcha").getContext("2d");
            ctx.clearRect(0, 0, 100, 50);
        },
        drawCaptcha(num) {
            while (num > 0) num.pop();

            const captcha = $.id("captcha");

            try {
                const [capW, capH] = [captcha.width, captcha.height];
            } catch (e) {
                const [capW, capH] = [100, 35]
            }

            const ctx = captcha.getContext("2d");

            for (let i = 0; i <= 3; i++) {
                const j = Math.floor(Math.random() * this.captcha.length)  // 产生随机索引

                const deg = Math.random() * 30 * Math.PI / 180;  // 产生随机角度

                let text = this.captcha[j];  // 随机字符

                num.push(text.toLowerCase());  // 存入数组

                const [x, y] = [10 + i * 20, 10 + Math.random() * 8]  // 随机坐标

                ctx.font = "bold 30px Arial";

                ctx.translate(x, y);  // 平移坐标系
                ctx.rotate(deg);  // 旋转坐标系

                ctx.fillStyle = this.randomColor();  // 随机颜色
                ctx.fillText(text, 0, 15);  // 绘制字符

                ctx.rotate(-deg);
                ctx.translate(-x, -y);

            }
            for (let i = 0; i <= 10; i++) {  // 绘制干扰线
                ctx.strokeStyle = this.randomColor();
                ctx.beginPath();

                const pointArr = Array.from({length: 4}, (_, index) => Math.random() * (index % 2 ? capW : capH))

                const [cosRes, sinRes] = this.mathKit.dirTran(...pointArr)

                ctx.moveTo(pointArr[0], pointArr[1]);
                ctx.lineTo(pointArr[0] + cosRes * 25, pointArr[1] + sinRes * 25);
                ctx.stroke();
            }
            for (let i = 0; i <= 30; i++) {  // 绘制干扰点
                ctx.strokeStyle = this.randomColor();
                ctx.beginPath();

                const pointArr = Array.from({length: 4}, (_, index) => Math.random() * (index % 2 ? capW : capH))

                const [cosRes, sinRes] = this.mathKit.dirTran(...pointArr)

                ctx.moveTo(pointArr[0], pointArr[1]);
                ctx.lineTo(pointArr[0] + cosRes * 2, pointArr[1] + sinRes * 2);
                ctx.stroke();
            }

        },
        getCaptcha() {
            request(appUrl, "", {type: "captcha"}, "POST")
                .then(res => {
                    this.captcha = res.data
                })
        },
        select(event, flag) {
            this.flag = flag;

            const selected = document.getElementsByClassName("selected");
            let target = event.target;

            if (target.nodeName !== 'A') {
                while (target.nodeName !== 'A') {
                    target = target.parentNode;
                }
            }

            if (selected.length && selected[0] !== target) selected[0].classList.remove("selected");
            target.classList.add("selected");
        }
    },
    watch: {
        captcha(newVal, oldVal) {
            this.drawCaptcha(this.nowCaptcha);
        },
        flag(newVal, oldVal) {
            if (newVal) this.getCaptcha();
        }
    },
}
</script>

<template>
    <div class="root">

        <header class="page-header">

            <div class="logo">

                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 256">
                    <path fill="#F7DF1E" d="M0 0h256v256H0z"/>
                    <path d="m67.312 213.932l19.59-11.856c3.78 6.701 7.218 12.371 15.465 12.371c7.905 0 12.89-3.092 12.89-15.12v-81.798h24.057v82.138c0 24.917-14.606 36.259-35.916 36.259c-19.245 0-30.416-9.967-36.087-21.996m85.07-2.576l19.588-11.341c5.157 8.421 11.859 14.607 23.715 14.607c9.969 0 16.325-4.984 16.325-11.858c0-8.248-6.53-11.17-17.528-15.98l-6.013-2.58c-17.357-7.387-28.87-16.667-28.87-36.257c0-18.044 13.747-31.792 35.228-31.792c15.294 0 26.292 5.328 34.196 19.247l-18.732 12.03c-4.125-7.389-8.591-10.31-15.465-10.31c-7.046 0-11.514 4.468-11.514 10.31c0 7.217 4.468 10.14 14.778 14.608l6.014 2.577c20.45 8.765 31.963 17.7 31.963 37.804c0 21.654-17.012 33.51-39.867 33.51c-22.339 0-36.774-10.654-43.819-24.574"/>
                </svg>

                <h1 class="logo-text">Login</h1>

            </div>

        </header>

        <div class="page-main">

            <header class="form-header">

                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 256 256">
                    <defs>
                        <linearGradient id="IconifyId1908e5d4a4c2715e61582" x1="43.896%" x2="66.16%" y1="1.951%"
                                        y2="95.244%">
                            <stop offset="28%" stop-color="#07C3F2"/>
                            <stop offset="94%" stop-color="#087CFA"/>
                        </linearGradient>
                        <linearGradient id="IconifyId1908e5d4a4c2715e61583" x1="33.063%" x2="70.362%" y1="15.078%"
                                        y2="84.685%">
                            <stop offset="14%" stop-color="#FCF84A"/>
                            <stop offset="37%" stop-color="#07C3F2"/>
                        </linearGradient>
                        <linearGradient id="IconifyId1908e5d4a4c2715e61584" x1="44.416%" x2="56.203%" y1="25.058%"
                                        y2="90.203%">
                            <stop offset="28%" stop-color="#07C3F2"/>
                            <stop offset="94%" stop-color="#087CFA"/>
                        </linearGradient>
                    </defs>
                    <path fill="url(#IconifyId1908e5d4a4c2715e61582)"
                          d="M34.507 231.36L0 26.827L63.813.347L104.56 24.56l37.333-20.133l77.787 29.866L176.053 256z"/>
                    <path fill="url(#IconifyId1908e5d4a4c2715e61583)"
                          d="m256 86.693l-33.04-81.6L163.013 0L70.48 88.907l24.907 114.586l46.506 32.614L256 168.4l-28-52.507z"/>
                    <path fill="url(#IconifyId1908e5d4a4c2715e61584)"
                          d="m204.72 74.533l23.28 41.36l28-29.2l-20.56-50.826z"/>
                    <path d="M48 48h160v160H48z"/>
                    <path fill="#FFF"
                          d="M67.947 177.76h60v10h-60zm56.8-109.84l-8.934 35.013L105.6 67.92H95.44L85.2 102.933L76.293 67.92h-14l17.147 60.027h11.253l9.814-34.747l9.706 34.747H121.6l17.12-60.027zm16.48 51.707l7.813-9.6a27.57 27.57 0 0 0 17.973 7.306c5.334 0 8.694-2.133 8.694-5.68v-.16c0-1.899-.665-3.27-3.058-4.57l-.382-.2l-.41-.198l-.216-.1l-.454-.198l-.238-.1l-.5-.198l-.531-.2l-.278-.1l-.58-.2l-.303-.102l-.63-.204l-.667-.206l-.347-.104l-.72-.21l-.758-.214l-.795-.216l-.835-.221l-1.605-.416l-1.144-.307l-.748-.207l-.734-.21l-.72-.215l-.707-.217l-.694-.222l-.68-.227l-.334-.115l-.658-.235l-.643-.241l-.629-.248l-.614-.255l-.301-.13l-.591-.267l-.576-.275c-5.582-2.748-8.889-6.796-8.998-14.338l-.002-.574c0-10.792 8.59-17.98 20.68-18.13l.386-.003a34.67 34.67 0 0 1 22.347 7.653l-6.88 9.974a28.1 28.1 0 0 0-15.653-5.92c-5.067 0-7.734 2.32-7.734 5.333v.187c0 2.402.988 3.856 4.09 5.227l.456.196q.237.098.487.194l.518.195l.548.196l.58.196l.611.199l.646.2l.679.203l1.083.312l.767.213l.803.217l1.719.452q.426.112.843.225l.826.23q.205.057.407.116l.8.236l.781.242l.765.247l.746.252l.728.26l.357.131l.7.27c7.724 3.045 12.013 7.432 12.138 15.507l.002.524c0 11.946-9.12 18.667-22.106 18.667a38.24 38.24 0 0 1-25.52-9.627"/>
                </svg>

                <h2 class="sub-title" style="margin-left: 10px">Webstorm</h2>

            </header>

            <form class="form" @submit.prevent="login">

                <div class="form-wrapper gapbottom-20">

                    <ul class="stdlist type-list">

                        <li class="type-item" @click="select($event, false)">

                            <a id="password-type" class="stdlink textlightmode stdText-18 underline-l slowtrans selected">

                                <span>By Password</span>

                            </a>

                        </li>

                        <li class="type-item" @click="select($event, true)">

                            <a id="register-type" class="stdlink textlightmode stdText-18 underline-l slowtrans">

                                <span>Register</span>

                            </a>

                        </li>

                    </ul>

                </div>

                <div class="field-container">

                    <div class="field-wrapper">

                        <i class="icon-user"></i>
                        <input class="stdtextinput-5 input-text-name" type="text" name="name" placeholder="username" v-model="userInfo.name" required>

                    </div>

                    <div class="field-wrapper">

                        <i class="icon-password"></i>
                        <input class="stdtextinput-5 input-text-password" type="password" name="password" placeholder="password" v-model="userInfo.password" required>

                    </div>

                    <div class="field-wrapper" v-if="flag">

                        <input class="input-text-captcha" type="text" name="captcha" placeholder="captcha" v-model="userInfo.captcha" required>

                        <canvas id="captcha" width="100" height="35" @click="updateCaptcha">

                        </canvas>

                    </div>

                    <input class="stdbtn submit-btn" type="submit" :value="flag ? 'Register' : 'Log in'">

                </div>

            </form>

        </div>

    </div>
</template>

<style>
@font-face {
    font-family: 'Losttimoh';
    src: url("@/assets/Losttimoh-3.ttf");
}

.page-main {
    position: absolute;
    left: 50%;
    top: 50%;
    margin-top: -315px;
    margin-left: -200px;
    width: 400px;
    height: 630px;
    background: #1c1c1c;
    box-shadow: 0 0 10px 0 rgba(0, 33, 79, 0.11);
    border-radius: 6px;
}

.form-header {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 30px 0;
}

.sub-title {
    font-size: 40px;
    font-weight: bold;
    color: #fff;
    margin-block-start: 0;
    margin-block-end: 0;
    font-family: 'Losttimoh', sans-serif;
}

.form {
    height: 82%;
}

.type-list {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
}

.field-container {
    display: flex;
    flex-direction: column;
    padding: 30px 20px;
    height: 50%;
    justify-content: space-around;
}

.field-wrapper {
    display: flex;
    flex-direction: row;
    width: 100%;
    justify-content: center;
}

.icon-user {
    width: 32px;
    height: 32px;
    background: url("@/assets/icon.png") -110px 6px no-repeat;
}

.icon-password {
    width: 32px;
    height: 32px;
    background: url("@/assets/icon.png") -80px 6px no-repeat;
}

.input-text-name {
    padding-right: 32%;
}

.input-text-password {
    width: 90%;
}

.input-text-captcha {
    width: 53%;
}

#captcha {
    cursor: pointer;
    background-color: #6e6e6e;
}

.submit-btn {
    background-image: linear-gradient(to right, #a6c1ee, #fbc2eb);
}

.submit-btn:hover {
    filter: brightness(90%);
    box-shadow: 0 0 10px 0 rgba(255, 255, 255, 0.11);
}

</style>