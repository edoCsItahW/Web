<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->

<script>
import {request, sleep} from "../../../../jsPackage/src/comFunc/index.js";


const appUrl = location.href + "api/";


export default {
    data() {
        return {
            fileData: null,
            formData: {
                name: "",
                desc: "",
                duration: "",
                fileName: "",
                fileData: ""
            }
        }
    },
    props: {
        message: {
            flag: Object,
            user: Object
        }
    },
    methods: {
        setHiddenField() {
            const hiddenInput = document.getElementById("hidden-field");

            hiddenInput.value = this.fileData;

        },
        async getFileData(file) {
            const reader = new FileReader();

            reader.onload = (e) => {
                this.fileData = e.target.result;
            }

            reader.readAsDataURL(file);

            let count = 0
            while (this.fileData === null && count < 10) {
                await sleep(1000);
                count++;
            }

            if (this.fileData === null || this.fileData === undefined) console.error("获取文件数据失败!");

            this.setHiddenField();

        },
        triggerClick() {
            const fileInput = document.getElementById("test-file");
            const fileInfoDiv = document.getElementById("file-info");
            const fileName = document.getElementById("file-name");
            const fileSize = document.getElementById("file-size");
            const moveBottoms = document.getElementsByClassName("need-move");

            fileInput.click();  // 触发文件选择框

            fileInput.onchange = () => {  // 文件选择框选择完毕
                const file = fileInput.files[0];  // 获取选择的文件
                fileInfoDiv.style.display = "block";
                this.formData.fileName = file.name;
                fileName.innerHTML = file.name;
                fileSize.innerHTML = `(${Math.trunc(file.size / 1024)}kb)`;

                this.getFileData(file);  // 获取文件数据

                for (let elem of moveBottoms) elem.classList.add("move-bottom");  // 下移元素
            }
        },
        cancelFile() {
            const fileInput = document.getElementById("test-file");
            const fileInfoDiv = document.getElementById("file-info");
            const moveBottoms = document.getElementsByClassName("need-move");

            fileInfoDiv.style.display = "none";
            for (let elem of moveBottoms) elem.classList.remove("move-bottom");  // 上移元素

            fileInput.value = "";
            this.fileData = null;

        },
        async waitAndColse() {

            // this.$emit('update:popupFlag', {type: "createTP", flag: false});
            this.$emit('message-sent', {type: "closePopup", data: false});
            this.$emit('message-sent', {type: "updateTP", data: null});
        },
        valueValid(event) {
            const [hour, minute] = event.target.value.split(":")

            if (Number(hour) * 60 + Number(minute) > 180) {
                const res = confirm("Are you sure your exam will take three hours?");

                if (!res) event.target.value = "00:00";
            }

        },
        async handleSubmit() {
            request(appUrl, "createTP", {...this.formData, userId: localStorage.getItem("userId")}, 'POST')
                    .then(res => {
                        if (res.code !== 200) {
                            console.error("创建试卷失败!");
                        } else {
                            this.waitAndColse();
                        }
                    })
        },
    },
    watch: {
        message: {
            handler(newVal, oldVal) {
                if (newVal.flag.back) this.$emit('message-sent', {type: "closePopup", data: false})
            },
            deep: true,
            immediate: true
        }
    }
}
</script>

<template>
    <div class="root">

        <header class="page-header" style="background-color: #202020;">

            <div class="logo">

                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 256 256">
                    <defs>
                        <linearGradient id="IconifyId1908614ef135babcd1560" x1="43.896%" x2="66.16%" y1="1.951%"
                                        y2="95.244%">
                            <stop offset="28%" stop-color="#07C3F2"/>
                            <stop offset="94%" stop-color="#087CFA"/>
                        </linearGradient>
                        <linearGradient id="IconifyId1908614ef135babcd1561" x1="33.063%" x2="70.362%" y1="15.078%"
                                        y2="84.685%">
                            <stop offset="14%" stop-color="#FCF84A"/>
                            <stop offset="37%" stop-color="#07C3F2"/>
                        </linearGradient>
                        <linearGradient id="IconifyId1908614ef135babcd1562" x1="44.416%" x2="56.203%" y1="25.058%"
                                        y2="90.203%">
                            <stop offset="28%" stop-color="#07C3F2"/>
                            <stop offset="94%" stop-color="#087CFA"/>
                        </linearGradient>
                    </defs>
                    <path fill="url(#IconifyId1908614ef135babcd1560)"
                          d="M34.507 231.36L0 26.827L63.813.347L104.56 24.56l37.333-20.133l77.787 29.866L176.053 256z"/>
                    <path fill="url(#IconifyId1908614ef135babcd1561)"
                          d="m256 86.693l-33.04-81.6L163.013 0L70.48 88.907l24.907 114.586l46.506 32.614L256 168.4l-28-52.507z"/>
                    <path fill="url(#IconifyId1908614ef135babcd1562)"
                          d="m204.72 74.533l23.28 41.36l28-29.2l-20.56-50.826z"/>
                    <path d="M48 48h160v160H48z"/>
                    <path fill="#FFF"
                          d="M67.947 177.76h60v10h-60zm56.8-109.84l-8.934 35.013L105.6 67.92H95.44L85.2 102.933L76.293 67.92h-14l17.147 60.027h11.253l9.814-34.747l9.706 34.747H121.6l17.12-60.027zm16.48 51.707l7.813-9.6a27.57 27.57 0 0 0 17.973 7.306c5.334 0 8.694-2.133 8.694-5.68v-.16c0-1.899-.665-3.27-3.058-4.57l-.382-.2l-.41-.198l-.216-.1l-.454-.198l-.238-.1l-.5-.198l-.531-.2l-.278-.1l-.58-.2l-.303-.102l-.63-.204l-.667-.206l-.347-.104l-.72-.21l-.758-.214l-.795-.216l-.835-.221l-1.605-.416l-1.144-.307l-.748-.207l-.734-.21l-.72-.215l-.707-.217l-.694-.222l-.68-.227l-.334-.115l-.658-.235l-.643-.241l-.629-.248l-.614-.255l-.301-.13l-.591-.267l-.576-.275c-5.582-2.748-8.889-6.796-8.998-14.338l-.002-.574c0-10.792 8.59-17.98 20.68-18.13l.386-.003a34.67 34.67 0 0 1 22.347 7.653l-6.88 9.974a28.1 28.1 0 0 0-15.653-5.92c-5.067 0-7.734 2.32-7.734 5.333v.187c0 2.402.988 3.856 4.09 5.227l.456.196q.237.098.487.194l.518.195l.548.196l.58.196l.611.199l.646.2l.679.203l1.083.312l.767.213l.803.217l1.719.452q.426.112.843.225l.826.23q.205.057.407.116l.8.236l.781.242l.765.247l.746.252l.728.26l.357.131l.7.27c7.724 3.045 12.013 7.432 12.138 15.507l.002.524c0 11.946-9.12 18.667-22.106 18.667a38.24 38.24 0 0 1-25.52-9.627"/>
                </svg>
                <h1 class="logo-text">Create Test Paper</h1>

            </div>

        </header>

        <div class="main-body">

            <h1>Create a new test paper</h1>

            <p class="std-text">The following form will help you create a new test paper.</p>

            <div class="form-container">
                <form @submit.prevent="handleSubmit">

                    <div class="field-group">

                        <input class="input-text-field field-widget" type="text" id="test-name" name="name"
                               placeholder="Enter the name of the test" v-model="formData.name" required>
                        <label class="field" for="test-name">Test Name</label>

                    </div>

                    <div class="field-group optional">

                        <input class="input-text-field field-widget" type="text" id="test-description" name="desc"
                               v-model="formData.desc" placeholder="Enter a brief description of the test">
                        <label class="field" for="test-description">Test Description</label>

                    </div>

                    <div class="field-group optional">

                        <input class="input-time-field field-widget" type="time" id="test-duration" name="duration"
                               v-model="formData.duration" @change="valueValid">
                        <label class="field" for="test-duration">Test Duration</label>

                    </div>

                    <div class="field-group optional">

                        <div class="field-widget input-file-field" id="file-info">

                            <span class="file-name" id="file-name"></span>
                            <span class="file-size" id="file-size"></span>
                            <a class="file-remove" href="javascript:void(0)" @click="cancelFile"></a>

                        </div>
                        <a class="disguise-button field-widget need-move" href="javascript:void(0)"
                           @click="triggerClick">
                            <span>Upload a test image</span>
                        </a>
                        <input class="input-file-field field-widget" type="file" id="test-file" name="fileName"
                               accept="image/*">
                        <label class="field" for="test-file">Upload a test image</label>

                    </div>

                    <div class="field-group">

                        <input id="hidden-field" type="hidden" style="display: none;" name="fileData"
                               v-model="formData.fileData">

                    </div>

                    <div class="field-group need-move">

                        <input class="input-submit-field field-widget" type="submit" value="Create Test Paper">

                    </div>

                </form>

            </div>

        </div>

    </div>
</template>

<style>
input[type="text"]::placeholder {
    color: black;
    font-size: 17px;
    font-style: italic;
    opacity: 0.8;
}

.main-body {
    padding: 0 15%;
    color: honeydew;
}

.std-text {
    font-size: 1.3em;
}

.form-container {
    background-color: #656565;
    padding: 50px 30px 20px 30px;
    border-radius: 10px;
}

.optional::before {
    content: "*";
    color: white;
}

.field-group {
    align-items: center;
    align-content: center;
    display: flex;
    margin-bottom: 40px;
}

.field {
    font-size: 1.2em;
}

.input-text-field {
    display: inline-block;
    padding: 8px 10px;
    font-size: 16px;
    border: 1px solid #cccbcb;
    width: 40%;
}

.disguise-button {
    font-size: 12px;
    font-weight: bold;
    color: #4b97ff;
    text-decoration: none;
    padding: 11px 32px;
    width: auto;
    border: 1px solid #cccbcb;
    border-radius: 19px;
    text-align: center;
    vertical-align: baseline;
    margin-bottom: 10px;
    float: left;
}

.input-file-field {
    display: none;
}

.input-time-field {
    display: inline-block;
    padding: 6px 10px;
    font-size: 16px;
    border: 1px solid #cccbcb;
}

.file-name {
    font-size: 100%;
    font-style: italic;
}

.file-size {
    font-size: 13px;
    margin-left: 0.5em;
    margin-top: 12px;
}

.file-remove {
    cursor: pointer;
    margin-left: 16px;
    text-decoration: none;
}

.file-remove::before {
    content: "\00d7";
    font-size: 20px;
    color: #ffffff;
    width: 13px;
    height: 13px;
}

.input-submit-field {
    margin-top: 20px;
    background-color: #52a3ff;
    color: white;
    font-size: 12px;
    font-weight: bold;
    padding: 16px 40px;
    line-height: 1.4;
    text-align: center;
    border-radius: 24px;
    vertical-align: baseline;
    cursor: pointer;
    text-decoration: none;
    position: relative;
    overflow: visible;
    border: none;
    transition: background-color 0.3s ease-in-out;
}

.input-submit-field:hover {
    background-color: #217fff;
}

.move-bottom {
    margin-top: 100px;
}

.field-widget {
    position: absolute;
    margin-left: 20%;
}

</style>
