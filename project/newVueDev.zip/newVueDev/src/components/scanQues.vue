<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->
<script>
import { request, sleep } from "../../../../jsPackage/src/comFunc/index.js";
import prevWindow from "@/components/prevWindow.vue";


const apiUrl = location.href + "api/"


export default {
    data() {
        return {
            quesPool: null,
            errMsgFlag: false,
            windowInfo: {type: "addQues", flag: false},
            nowType: 'choice',
            quesIdx: 1,
            formData: {
                question: "",
                options: {
                    A: "",
                    B: "",
                    C: "",
                    D: ""
                },
                answer: ""
            },
            quesType: {
                choice: {
                    question: {num: 1, type: "text", "class": "input-text-field field-widget"},
                    options: {num: 4, type: "text", "class": "input-text-field field-widget"},
                    answer: {num: 1, type: "text", "class": "input-text-field field-widget"},
                }
            },
            options: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"],
        }
    },
    created() {
        this.getQuesPoor();
    },
    methods: {
        getQuesPoor() {
            request(apiUrl, "", {type: "getQuesPool", id: this.message.id, userId: this.message.userId}, "POST")
                .then(res => {
                    this.quesPool = res.data.quesPool;
                })
        },
        checkQuesPool() {
            if (this.quesPool === null || this.quesPool === undefined) {
                return false;
            }
            else {
                return Object.keys(this.quesPool).length > 0;
            }
        },
        selectType(event) {
            const type = document.getElementsByClassName("selected");

            if (type.length && type[0] !== event.target) {
                type[0].classList.remove("selected");
                event.target.classList.add("selected");
            }
            else event.target.classList.add("selected");

            const keyMap = {
                choice: "choice",
                multiplechoice: "multiChoice",
                judgement: "judgement",
                other: "other"
            }

            this.nowType = keyMap[event.target.innerHTML.toLowerCase().replace(" ", "")]

        },
        handleSubmit() {
            const data = {...this.formData, type: this.nowType, TPid: this.message.id, id: this.quesIdx, userId: this.message.userId}

            request(apiUrl, "addQues", data, "POST")
                .then(res => {
                    if (res.code !== 200) {
                        console.log(res.msg);
                        alert(res.msg);
                    }
                })

            this.addAndClose();
        },
        addAndClose() {
            this.quesIdx++
            this.windowInfo.flag = false;
            this.$emit('message-sent', {type: "cancelScroll", data: "hidden"});

            this.getQuesPoor();
        },
        beginAddQues() {
            this.windowInfo.flag = true;
            this.$emit('message-sent', {type: 'showScroll', data: 'scroll'})
        },
        beginExam() {
            this.$emit('message-sent', {type: "beginExam", data: this.message.id});
        }
    },
    props: {
        message: {
            name: String,
            id: Number,
            flag: Object,
            userId: Number
        },
    },
    components: {
        prevWindow,
    },
    watch: {
        message: {
            handler(newVal, oldVal) {
                if (!newVal.flag.flag) this.windowInfo.flag = false;
                if (oldVal && newVal.id !== oldVal.id) this.getQuesPoor();
                if (newVal.flag.back) {
                    if (this.windowInfo.flag) {
                        this.windowInfo.flag = false;
                        this.$emit('message-sent', {type: "resetBack", data: false});
                    }
                    else {
                        this.$emit('message-sent', {type: "closePopup", data: false});
                    }
                }
            },
            deep: true,
            immediate: true
        },
    },
    setup() {

    }
}
</script>

<template>
    <div class="root">

        <header class="page-header" style="background-color: #092035;">

            <div class="logo">

                <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 512 225">
                    <path fill="#14D8CC" fill-rule="evenodd" d="M512 7.66v158.324c0 4.231-3.44 7.66-7.68 7.66H327.68v43.412c0 4.231-3.438 7.66-7.68 7.66H7.68c-4.242 0-7.68-3.429-7.68-7.66V58.733c0-4.229 3.438-7.661 7.68-7.661h304.64V7.661C312.32 3.429 315.76 0 320 0h184.32c4.24 0 7.68 3.43 7.68 7.66m-50.596 45.455a2.05 2.05 0 0 0-2.045-2.043h-10.24a2.05 2.05 0 0 0-2.048 2.043v38.398c0 .613-.717.818-.922.205L432.123 52.91c-.307-.922-1.024-1.839-2.56-1.839H417.38a2.05 2.05 0 0 0-2.048 2.043v67.402c0 1.124.924 2.043 2.048 2.043h10.237a2.05 2.05 0 0 0 2.048-2.043V85.18c0-.612.717-.814.922-.204l13.926 35.848c.305.817 1.022 1.736 2.763 1.736h12.083a2.05 2.05 0 0 0 2.045-2.043zm-57.444 57.698a2.05 2.05 0 0 0-2.048-2.04h-8.701c-.615 0-1.024-.406-1.024-1.021V65.88c0-.613.41-1.024 1.024-1.024h7.68a2.05 2.05 0 0 0 2.045-2.04v-9.701a2.05 2.05 0 0 0-2.045-2.043h-31.739c-1.126 0-2.05.917-2.05 2.043v9.701a2.05 2.05 0 0 0 2.05 2.04h7.677c.615 0 1.024.411 1.024 1.024v41.872c0 .615-.41 1.021-1.024 1.021h-8.701a2.05 2.05 0 0 0-2.048 2.04v9.704c0 1.124.922 2.043 2.048 2.043h33.784a2.05 2.05 0 0 0 2.048-2.043zm-91.64-44.42H16.64a1.28 1.28 0 0 0-1.28 1.277v140.448c0 .705.573 1.277 1.28 1.277h294.4c.707 0 1.28-.572 1.28-1.277zm-45.376 92.941c1.126 0 2.048.92 2.048 2.043v10.212a2.05 2.05 0 0 1-2.048 2.043h-37.573a2.05 2.05 0 0 1-2.048-2.043v-67.402a2.05 2.05 0 0 1 2.048-2.043h37.163a2.05 2.05 0 0 1 2.048 2.043v10.212a2.05 2.05 0 0 1-2.048 2.043H242.68c-.614 0-1.026.408-1.026 1.021v12.255c0 .613.412 1.021 1.026 1.021h23.035c1.127 0 2.048.92 2.048 2.043v10.212a2.05 2.05 0 0 1-2.048 2.043H242.68c-.614 0-1.026.408-1.026 1.021v12.255c0 .613.412 1.021 1.026 1.021zm-53.04-57.19a2.05 2.05 0 0 1 2.045 2.043v67.402a2.05 2.05 0 0 1-2.046 2.043H201.82c-1.74 0-2.457-.92-2.762-1.736l-13.926-35.848c-.205-.61-.922-.408-.922.204v35.337a2.05 2.05 0 0 1-2.048 2.043h-10.238a2.053 2.053 0 0 1-2.048-2.043v-67.402c0-1.126.925-2.043 2.048-2.043h12.184c1.538 0 2.252.917 2.56 1.839l14.026 38.807c.207.613.921.408.921-.205v-38.398a2.05 2.05 0 0 1 2.048-2.043zm-57.754 0c1.129 0 2.048.917 2.048 2.043v48c0 12.357-10.238 22.569-24.369 22.569c-13.921 0-24.161-10.212-24.161-22.57v-48a2.05 2.05 0 0 1 2.05-2.042h10.34c1.124 0 2.048.917 2.048 2.043v48c0 4.492 3.684 8.169 9.723 8.169c6.25 0 9.933-3.677 9.933-8.17v-48a2.05 2.05 0 0 1 2.048-2.042zm-56.318 2.043v10.212a2.05 2.05 0 0 1-2.048 2.043H84.987c-.615 0-1.024.408-1.024 1.021v54.126a2.053 2.053 0 0 1-2.048 2.043H71.677a2.05 2.05 0 0 1-2.048-2.043v-54.126c0-.613-.41-1.021-1.024-1.021H55.808a2.05 2.05 0 0 1-2.048-2.043v-10.212c0-1.126.919-2.043 2.048-2.043h41.976a2.05 2.05 0 0 1 2.048 2.043"/>
                </svg>
                <h1 class="logo-text">Browsing Questions For {{ message['name'] }}</h1>

            </div>

        </header>

        <div class="ques-add-window" v-if="windowInfo.type === 'addQues' && windowInfo.flag">

            <h1>Add a question</h1>

            <p class="std-text">To add a question, please complete the following fields.</p>

            <div class="form-container">

                <form @submit.prevent="handleSubmit">

                    <div class="field-group">

                        <label class="field">Question Type</label>
                        <div class="ques-type field-widget">

                            <ul class="ques-type-list">

                                <li class="ques-type-item">
                                    <a class="selected" href="javascript:void(0)" @click="selectType">Choice</a>
                                </li>

                                <li class="ques-type-item">
                                    <a href="javascript:void(0)" @click="selectType">Multiple Choice</a>
                                </li>

                                <li class="ques-type-item">
                                    <a href="javascript:void(0)" @click="selectType">Judgement</a>
                                </li>

                                <li class="ques-type-item" style="padding-right: 0;">
                                    <a href="javascript:void(0)" @click="selectType">Other</a>
                                </li>

                            </ul>

                        </div>

                    </div>

                    <div class="field-group">

                        <label class="field">Pervious</label>

                        <prev-window />

                    </div>

                    <div style="flex-direction: column;" v-for="(value, key) in quesType[nowType]">

                        <div class="field-group" v-for="i in value.num">

                            <label class="field" v-if="value.num <= 1">{{ key }}</label>
                            <label class="field" v-else>{{ key }}{{ options[i - 1] }}</label>
                            <input :class="value.class" v-if="value.num <= 1" :type="value.type" :name="key"
                                   :placeholder="`Please enter ${key}`" v-model="formData[key]" required>
                            <input v-else :class="value.class" :type="value.type" :name="`${key}${options[i - 1]}`"
                                   :placeholder="`Please enter ${key}${options[i - 1]}`" v-model="formData[key][options[i - 1]]" required>

                        </div>

                    </div>

                    <div class="field-group">

                        <input class="input-submit-field field-widget" type="submit" value="Add Question">

                    </div>

                </form>

            </div>

        </div>

        <div class="main-window" v-if="!windowInfo.flag">

            <div class="ques-list" v-if="checkQuesPool()">

                <div class="ques-item" v-for="(ques, type) in quesPool" @click="console.log(ques)">

                    <h1 class="ques-type-title">{{ type }}</h1>

                    <div class="ques-item-content" v-for="(question, idx) in ques.questions" @click="console.log(question)">

                        <b style="font-size: 18px;">{{ question.id }}</b>. {{ question.question }}

                    </div>

                </div>

            </div>

            <div class="window-none" v-if="!checkQuesPool()" @click="beginAddQues" @mouseenter="errMsgFlag = true; getQuesPoor();" @mouseleave="errMsgFlag = false">

                <div class="icon-none"></div>
                <span id="error-msg" v-show="errMsgFlag">You have not added any questions yet, And you can push this window to add a question.</span>

            </div>

            <div class="option-block" v-if="checkQuesPool()">

                <a class="std-btn add-question" @click="beginAddQues">
                    <span>Add a question</span>
                </a>

                <a class="std-btn begin-exam" @click="beginExam">
                    <span>Begin Exam</span>
                </a>

            </div>

        </div>

    </div>
</template>

<style>
input[type="text"]::placeholder {
    color: black;
    font-size: 17px;
    font-style: italic;
    opacity: 0.8;
}

.std-link {
    text-decoration: none;
    color: #cdcdcd;
}

li[class^="ques-type-item"] a {
    color: #cdcdcd;
    font-size: 18px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
}

li[class^="ques-type-item"] a:hover {
    color: #ededed;
    border-bottom: 3px solid #ededed;
}

.main-window {
    display: flex;
    flex-direction: column;
}

.ques-list {
    display: flex;
    flex-direction: column;
}

.ques-item {
    background-color: #344c6e;
    border-radius: 10px;
}

.window-none {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    transition: all 0.3s ease-in-out;
    flex-direction: column;
}

.window-none:hover {
    filter: grayscale(1.1);
    background-color: #777777;
}

.option-block {
    display: flex;
    margin-top: 20px;
    justify-content: space-around;
    align-items: center;
}

.std-btn {
    color: #cdcdcd;
    background-color: #1a2f49;
    font-size: 12px;
    font-weight: bold;
    text-decoration: none;
    padding: 11px 32px;
    width: auto;
    border: 2px solid #000000;
    border-radius: 19px;
    text-align: center;
    vertical-align: baseline;
    margin-bottom: 10px;
    float: left;
    transition: all 0.3s ease-in-out;
}

.std-btn:hover {
    background-color: #233f67;
    border-color: #454545;
    color: white;
}

.icon-none {
    content: url('/src/assets/add.svg');
    display: inline-block;
    width: 128px;
    height: 128px;
    margin-bottom: 20px;
}

#error-msg {
    color: white;
}

.ques-type {
    text-align: left;
}

.ques-type-list {
    list-style: none;
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: row;
    padding-inline-start: 0;
}

.ques-type-item {
    float: left;
    position: relative;
    padding-right: 27px;
    color: #cdcdcd;
    border-bottom: 1px solid #d3d3d3;
}

.selected {
    color: #18a3fa !important;
    display: inline-block;
    cursor: pointer;
    border-bottom: 3px solid #18a3fa !important;
}

.ques-add-window {
    padding: 0 10%;
    color: #cdcdcd;
}

.ques-item {
    padding: 0 20px 20px 20px;
    color: #cdcdcd;
}

.ques-item-content {
    padding:0 20px;
    margin-bottom: 10px;
    background-color: #4980ca;
    line-height: 3;
    border-radius: 10px;
}

.ques-type-title {
    color: honeydew;
}

.adjust-prev {
    margin-bottom: 43%;
}

</style>