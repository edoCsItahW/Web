<!--
  - Copyright (c) 2024. All rights reserved.
  - This source code is licensed under the CC BY-NC-SA
  - (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
  - This software is protected by copyright law. Reproduction, distribution, or use for commercial
  - purposes is prohibited without the author's permission. If you have any questions or require
  - permission, please contact the author: 2207150234@st.sziit.edu.cn
  -->

<script>
const options = {A: "Option A", B: "Option B", C: "Option C", D: "Option D"}


const prevType = {
    classList: ["prev-module", "prev-type"],
    content: "<span style='margin-left: 5%;'><b style='font-size: 20px;'>Choice</b></span>"
}

const prevQues = {
    classList: ["prev-module", "prev-ques"],
    content: "<span style='margin-left: 5%;'><b style='font-size: 20px;'>1</b>. Example question 1</span>"
}

const prevOption = {
    classList: ["prev-module", "prev-option"],
    content: "<div style='display: flex; flex-direction: column;'>"
            + Object.entries(options).map(([k, v]) => { return `<p style='margin-block-start: 0; margin-block-end: 0; margin-left: 10%;'><b>${k}</b>. ${v}</p>`; }).join("")
            + "</div>"
}

const prevAns = {
    classList: ["prev-module", "prev-ans"],
    content: "<span style='margin-left: 5%;'>Answer of the question</span>"
}


export default {
    data() {
        return {
            prevElems: [prevType, prevQues, prevOption, prevAns],
        }
    }
}
</script>

<template>
    <div class="prev-window field-widget">

        <div class="prev-table">

            <div v-for="elem in prevElems" :class="elem.classList" v-html="elem.content"></div>

        </div>

        <div class="prev-block">



        </div>

    </div>

</template>

<style>
.prev-window {
    border: 2px solid #ededed;
    width: 40%;
    height: 50%;
    margin-top: 30%;
    background-color: #1c1c1c;
}

.prev-module {
    color: white;
    align-content: center;
    cursor: pointer;
    border-radius: 8px;
}

.prev-type {
    background-color: #1a2f49;
}

.prev-ques {
    font-size: 18px;
    background-color: #1e1149;
}

.prev-option {
    background-color: #504a00;
}

.prev-ans {
    background-color: #733d00;
}

</style>