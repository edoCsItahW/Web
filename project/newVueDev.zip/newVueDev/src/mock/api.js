/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
let user = [
    {
        id: 1,
        name: "admin",
        password: "123456",
        ip: "127.0.0.1",
        TPs: [
            {
                id: 1,
                name: "Math Test",
                desc: "A test paper for Math Exam.",
                fileName: "",
                fileData: "",
                quesPool: {
                    choice: {
                        cnName: "单选题",
                        questions: [
                            {
                                id: 1,
                                question: "Example question 1",
                                options: {
                                    A: "Option A",
                                    B: "Option B",
                                    C: "Option C",
                                    D: "Option D"
                                },
                                answer: "A"
                            },
                            {
                                id: 2,
                                question: "Example question 2",
                                options: {
                                    A: "Option A",
                                    B: "Option B",
                                    C: "Option C",
                                    D: "Option D"
                                },
                                answer: "B"
                            }
                        ]
                    }
                }
            }
        ]
    }
]


function stdRes(data, code = 200, msg = 'ok') {
    return {code: code, msg: msg, data: data}
}


function fillTP(data) {
    if (typeof data === "object") {
        return {id: user[data.userId - 1].TPs.length + 1, name: data.name, desc: data.desc, fileName: data.fileName, fileData: data.fileData, quesPool: {}}
    }
}


function createTP(data) {
    console.log("createTP: ", data.body, "\n")
    let body = data.body;

    console.log("createTP-TP-beforeAdd: ", user[body.userId - 1].TPs, "\n");
    user[body.userId - 1].TPs.push(fillTP(body))
    console.log("createTP-TP-afterAdd: ", user[body.userId - 1].TPs, "\n");
    return stdRes(null)
}


function addQues(data) {
    console.log("addQues: ", data.body, "\n")
    const body = data.body;

    const tps = user[body.userId - 1].TPs

    if (body.type in tps[body.TPid - 1].quesPool) {

        delete data.body.TPid;
        delete data.body.type;
        delete data.body.userId;

        console.log("addQues-ques-beforeAdd: ", user[body.userId - 1].TPs[body.TPid - 1].quesPool[body.type].questions, "\n")
        user[body.userId - 1].TPs[body.TPid - 1].quesPool[body.type].questions.push(data.body)
        console.log("addQues-ques-afterAdd: ", user[body.userId - 1].TPs[body.TPid - 1].quesPool[body.type].questions, "\n")
    }
    else {
        delete data.body.TPid;
        delete data.body.type;
        delete data.body.userId;

        console.log("addQues-user-test: ", user, body, user[body.userId - 1], "\n")

        try {
            user[body.userId - 1].TPs[body.TPid - 1].quesPool[body.type] = {cnName: '无', questions: [Object.fromEntries(Object.entries(body).map(([key, value]) => {
                    if (!['TPid', 'type'].includes(key)) return [key, value]
                }))]}
        } catch (e) {
            console.log("addQues-error: ", e, "\n")
        }


    }

    return stdRes(null);
}


function normalApi(data) {

    console.log("normalApi: ", data.body, "\n")

    const body = data.body;

    if (data.body.type === 'userInfo') {

        if (typeof body.data === 'number') return stdRes(user[body.data - 1]);
        return stdRes(null);
    }
    else if (body.type === 'getQuesPool') {
        console.log("getQuesPool: ", user, body, user[body.userId - 1], "\n")
        return stdRes(user[body.userId - 1].TPs[body.id - 1]);
    }
    else if (body.type === 'captcha') return stdRes(Array.from({length: 4}, () => Math.floor(Math.random() * 10)).join(''));
    else if (body.type === 'register') {
        if (user.some(item => item.name === body.name)) return stdRes(null, 400, '用户名已存在');
        if (user.some(item => item.ip === body.ip)) return stdRes(null, 400, 'IP地址已存在');

        user.push({id: user.length + 1, name: body.name, password: body.password, ip: body.ip, TPs: []})

        return stdRes(null);
    }
    else if (body.type === 'login') {
        if (user.some(item => item.name === body.name && item.password === body.password)) {
            return stdRes(user.findIndex(item => item.name === body.name && item.password === body.password) + 1)
        }
        else {
            return stdRes(null, 400, '用户名或密码错误')
        }
    }
}


export default [
    {
        url: '/api', //请求地址
        method: 'POST',
        response: (data) => normalApi(data)
    },
    {
        url: '/api/createTP', //请求地址
        method: 'post', //请求方式
        response: (data) => createTP(data)
    },
    {
        url: '/api/addQues',
        method: 'post',
        response: (data) => addQues(data)
    },
    {
        url: '/api/getQuesPool',
        method: 'post',
        response: (data) => normalApi(((_data) => {
            _data.body.type = 'getQuesPool';
            return normalApi(_data)
        })(data))
    }
]
