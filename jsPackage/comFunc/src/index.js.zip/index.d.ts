/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
export class $ {
    static id(elementId: string): HTMLElement
    static class(classNames: string, index?: number): HTMLCollection
    static toHash(str: string): string
    static getComplement(bigArr: any[], smallArr: any[]): any[]
}

export class errHandle {
    static checkType(value: any, type: string, msg: string, raiseType: string): void
    static tryExec(func: Function): Function
}

export class elemOption {
    static removeAllChild(elem: HTMLElement): void
    static createNewElement_(tag: string, className: string, id: string, otherAttr: object, postion: HTMLElement, method: number): HTMLElement
    static _createNewElement(postion: HTMLElement, tag: string, content: string, className: string, id: string, otherAtt: object, method: number): HTMLElement
}

export function request(url: string, reqHead: string, data: any, method?: string, contentType?: string): Promise<any>

export function sleep(ms: number): Promise<void>
