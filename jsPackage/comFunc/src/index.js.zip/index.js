/*
 Copyright (c) 2024. All rights reserved.
 This source code is licensed under the CC BY-NC-SA
 (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 This software is protected by copyright law. Reproduction, distribution, or use for commercial
 purposes is prohibited without the author's permission. If you have any questions or require
 permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
import CryptoJS from "crypto-js"


class $ {
    static id(elementId) {
        return document.getElementById(elementId)
    }

    static class(classNames, index = 0) {
        return (typeof index === "number" ? document.getElementsByClassName(classNames)[index] : document.getElementsByClassName(classNames))
    }

    static toHash(string) {
        // return crypto.createHash('sha256').update(string).digest('hex')
        return CryptoJS.SHA256(string).toString()
    }

    static getComplement(bigArray, smallArray) {
        /* 获取数组bigArray对smallArray的补集(bigArray包含smallArray)(bigArray中存在但smallArray中不存在的元素)
        *
        * @param {Array} bigArray - 包含smallArray中所有元素的数组
        * @param {Array} smallArray - 该数组中的所有元素都可以在数组bigArray中被找到
        * */

        errHandle.checkType(bigArray, "Array", "#bigArray")
        errHandle.checkType(smallArray, "Array", "#samllArray")

        return bigArray.filter(element => !smallArray.includes(element))
    }
}


class errHandle {
    static checkType(element, type, message = "一个错误发生了", raiseType = "warn") {
        /* 检查类型是否符合期望
        *
        * @param {string} type - 类型
        * @param {any} element - 受检查的数据
        * @param {string} message - 当参数类型不符合期望时输出的信息
        * @param {string} raiseType - 引发错误或警告的方式, none: 忽略, print: 仅输出, warn: 警告, error: 调式错误, stop: 致命错误-程序终止
        * */
        const methodObj = {
            none: message => {
            },
            print: message => {
                console.log(message)
            },
            warn: message => {
                console.warn(message)
            },
            error: message => {
                console.error(message)
            },
            stop: message => {
                throw new Error(message)
            }
        }

        message = message.startsWith("#") ? `参数'${message.replace("#", "").replace(" ", "")}'接收了一个非期望的输入!` : message

        if (!methodObj.hasOwnProperty(raiseType)) console.error(`位置参数'raiseTypoe'只允许['print', 'warn', 'error', 'stop'],而接收到的参数'${raiseType}'`)

        const typeArray = ["object", "string", "number", "boolean", "function", "symbol", "undefine"]

        if (typeArray.includes(element)) {
            if (typeof element === type) {
                return true
            } else {
                methodObj[raiseType](message)

                return false
            }
        } else if (type === "Array") {

            if (Array.isArray(element)) {

                return true
            } else {

                methodObj[raiseType](message)

                return false
            }
        } else {
            methodObj[raiseType](`'${type}'并非预设类型!`)
        }
    }

    static format() {

    }

    static tryExec(func) {
        function exec() {
            try {
                func.apply(this, arguments);
            }
            catch (error) {
                console.error("msg", error.message);
                console.error("line", error.stack.split('\n')[1].trim().split(':')[1]);
                console.error("file", error.stack.split('\n')[1].trim().split(':')[0].split('(')[1]);

                const stackLine = error.stack.split('\n')[1].trim();
                const funcName = stackLine.substring(0, stackLine.indexOf(' '));
                console.error("func", funcName);
            }
        }
        return exec
    }
}


class elemOption {
    static removeAllChild(elem) {
        /* 移除所有子元素 */
        if (elem.children.length) {
            Array.from(elem.children).forEach(e => elem.removeChild(e))
        }
    }

    static createNewElement_(tag, content = null, className = null, id = null, otherAtt = null, postion = document.body, method = 1) {
        /* 创建新的子节点(postion在尾部)
         *
         * @param {string} tag - 标签名称
         * @param {string} content - 节点内容
         * @param {string} className - 类名属性值
         * @param {string} id - id属性值
         * @param {object} otherAtt - 其它属性的键值对
         * @param {HTMLElement} postion - 插入位置(默认为document.body)
         */
        let element = document.createElement(tag)
        if (content) {
            element.innerHTML = content
        }
        if (className) {
            if (Array.isArray(className)) {
                for (let i of className) {
                    element.classList.add(i)
                }
            } else {
                element.className = className
            }
        }
        if (id) {
            element.id = id
        }
        if (otherAtt) {
            if (typeof otherAtt === "object") {
                Object.entries(otherAtt).forEach(([k, v]) => {
                    element.setAttribute(k, v)
                })
            }
        }
        if (postion) {
            if (typeof method === "number") {
                if (method > 0) {
                    postion.appendChild(element)
                } else {
                    postion.prepend(element)
                }
            } else {
                postion.insertBefore(element, method)
            }
        }
        return element
    }

    static _createNewElement(postion = document.body, tag, content = null, className = null, id = null, otherAtt = null, method = 1) {
        /* 创建新的子节点(postion在开头)
         * 
         * @param {string} tag - 标签名称
         * @param {string} content - 节点内容
         * @param {string} className - 类名属性值
         * @param {string} id - id属性值
         * @param {object} otherAtt - 其它属性的键值对
         * @param {HTMLElement} postion - 插入位置(默认为document.body) 
         */
        let element = document.createElement(tag)
        if (content) {
            element.innerHTML = content
        }
        if (className) {
            if (Array.isArray(className)) {
                for (let i of className) {
                    element.classList.add(i)
                }
            } else {
                element.className = className
            }
        }
        if (id) {
            element.id = id
        }
        if (otherAtt) {
            if (typeof otherAtt === "object") {
                Object.entries(otherAtt).forEach(([k, v]) => {
                    element.setAttribute(k, v)
                })
            }
        }
        if (postion) {
            if (typeof method === "number") {
                if (method > 0) {
                    postion.appendChild(element)
                } else {
                    postion.prepend(element)
                }
            } else {
                postion.insertBefore(element, method)
            }
        }
        return element
    }

    static groupRepel(elemArray, repelArray, evType = 'change', setKey = "checked", newValue = false) {
        /* 互斥元素
         * 
         * @param {Array} elemArray - 互斥元素所在的组
         * @param {Array} repelArray - 包含互斥元素的组
         */
        errHandle.checkType(elemArray, "Array", "#elemArray", "error")

        const group1 = errHandle.checkType(repelArray, "Array", "#repelArray", "warn") ? repelArray : [repelArray]
        const grout2 = $.getComplement(elemArray, group1)

        group1.forEach(element => element.addEventListener(evType, ev => {
            if (ev.target.checked) grout2.forEach(elem => elem.setAttribute(setKey, newValue))
        }))

        grout2.forEach(element => element.addEventListener(evType, ev => {
            if (ev.target.checked) group1.forEach(elem => elem.setAttribute(setKey, newValue))
        }))
    }

    static elementRepel(elementArray, evType = "change", setKey = "checked", newValue = false) {

        elementArray.forEach(element => element.addEventListener(evType, ev => {

            let classList = Array.from(ev.target.classList)

            if (classList.includes("enable")) {

                if (classList.includes("choice")) {

                    ev.target.classList.remove("choice")

                } else {

                    ev.target.classList.add("choice")

                    $.getComplement(elementArray, [ev.target]).forEach(elem => {

                        elem.classList.remove("choice")

                    })
                }

            }

        }))
    }

    static _findTag(element, tagName, resArr) {

        if (element.tagName === tagName.toUpperCase()) {
            resArr.push(element);
        }

        for (let elem of element.children) {
            this._findTag(elem, tagName, resArr)
        }

    }

    static findTag(element, tagName) {
        let resArr = [];

        this._findTag(element, tagName, resArr);

        return resArr;

    }

}


async function request(url, reqHead, data, method = "POST", contentType = "application/json") {
    /*
    发送请求

    @param {string} url - 目标路径
    @param {string} reqHead - 用于描述请求部分和目的的字段
    @param {object} data 请求内容
    @return {object} 返回的json数据,包括code,msg,body
    */

    const response = await fetch(route.join(url, reqHead), {
        method: method,
        headers: {"Content-Type": contentType},
        body: contentType === "application/json" ? JSON.stringify(data) : data
    })

    if (!response.ok) {
        console.warn(`请求: ${location.href} => ${response.url}\n状态: ${response.statusText}(${response.status})`)
    }

    return await response.json()
}


function debounce(func, wait) {
    let timeout
    return (...args) => {
        const context = this
        clearTimeout(timeout)
        timeout = setTimeout(() => func.apply(context, args), wait)
    }
}


class route {
    static _removeEnd(AnyStr) {
        return AnyStr.replace(/\/$/, '')
    }

    static _removeStart(AnyStr) {
        return AnyStr.replace(/^\//, '')
    }

    static join(_path) {
        return Array.from(arguments).map(v => this._removeEnd(this._removeStart(v))).join("/")
    }
}


async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


export {
    $,
    elemOption,
    request,
    debounce,
    route,
    sleep
}

